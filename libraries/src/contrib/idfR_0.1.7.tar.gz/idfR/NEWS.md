# idfR 0.1.7 (2022-04-13)

* opvragen van xy-coordinaten
* clip functie op basis van extent

# idfR 0.1.6 (2021-12-27)

* opvragen van kolom en rij nummers op basis van coordinaten

# idfR 0.1.5 (2020-10-22)

* update R-paketten

# idfR 0.1.4 (2020-03-04)

* reading and writing of single and double precision
* suporting non-equidistant idf

# idfR 0.1.3 (2020-02-20)

* update minimum en maximum waarde bij wegschrijven van idf-bestand

# idfR 0.1.2 (2020-02-04)

* inlezen van idf-bestand inclusief opzet (list-object)
* wegschrijven van een idf-bestand

# idfR 0.1.1 (2020-02-04)

* bug bij gedeeltelijk inlezen van idf-bestand

# idfR 0.1.0 (2020-01-22)

* eerste versie van de idfR beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
