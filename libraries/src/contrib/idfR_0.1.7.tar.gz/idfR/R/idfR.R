#' idfR
#'
#' A tool for handling idf-files (\href{https://oss.deltares.nl/web/imod/online-imod-user-manual}{iMOD})
#'
#' Try the examples to get convenient with \pkg{idfR}.
#'
"_PACKAGE"
