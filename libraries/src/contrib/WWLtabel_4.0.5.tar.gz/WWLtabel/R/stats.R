#' get floor
#'
#' @param value value.
#' @param stepsize resolution.
#' @param max_value maximum value to return.
#' @return floor value
#' @keywords internal
get_floor <- function(value, stepsize, max_value) {

  # ---- main part of procedure ----

  floor_value <- floor(value / stepsize) * stepsize
  ceiling_value <- ceiling(value / stepsize) * stepsize
  ceiling_value[ceiling_value == floor_value] <- ceiling_value[ceiling_value == floor_value] + stepsize
  floor_value[ceiling_value > max_value] <- floor_value[ceiling_value > max_value] - stepsize

  # ---- return of procedure ----

  return(floor_value)
}

#' get ceiling
#'
#' @param value value.
#' @param stepsize resolution.
#' @param max_value maximum value to return.
#' @return ceiling value
#' @keywords internal
get_ceiling <- function(value, stepsize, max_value) {

  # ---- main part of procedure ----

  floor_value <- floor(value / stepsize) * stepsize
  ceiling_value <- ceiling(value / stepsize) * stepsize
  ceiling_value[ceiling_value == floor_value] <- ceiling_value[ceiling_value == floor_value] + stepsize
  ceiling_value[ceiling_value > max_value] <- ceiling_value[ceiling_value > max_value] - stepsize

  # ---- return of procedure ----

  return(ceiling_value)
}
