#' Load wwl settings from (control)file
#'
#' @param file character string. Name of (control)file.
#' @importFrom utils head
#' @importFrom stringr str_c
#' @importFrom readr read_rds read_lines
#' @importFrom fs path_package path_file
#' @importFrom controlR get_record get_dir file_exists is_numeric
#' @importFrom apiwwl get_version
#' @return Watervision agriculture object.
#' @keywords internal
load_wwl_settings <- function(file) {

  # ---- main part of procedure ----

  message(str_c("reading file: ", path_file(file)))

  # load settings watervision agriculture
  wwl <- read_rds(file = str_c(path_package(package = "WWLtabel"), "/rds/wwl_settings.rds"))

  # load controlfile
  if (!controlR::file_exists(file = file)) stop()
  text <- read_lines(file = file, lazy = FALSE)

  # set directories
  wwl[["DIROUT"]] <- get_dir(text = text, item = "DIROUT")

  # load settings simulation
  URL <- get_record(text = text, item = "URL", item_exists = FALSE)
  if (!is.null(URL)) {
    wwl[["URL"]] <- URL
    DATABASE <- get_record(text = text, item = "DATABASE")
  } else {
    DATABASE <- get_record(text = text, item = "DATABASE", opt = get_version())
  }
  wwl[["DATABASE"]] <- DATABASE
  PROXY <- get_record(text = text, item = "PROXY", item_exists = FALSE)
  if (!is.null(PROXY)) {
    PROXYPWD <- get_record(text = text, item = "PROXYPWD", item_exists = FALSE)
    if (is.null(PROXYPWD)) {
      PROXYPWD <- NULL
    } else {
      if (PROXYPWD == "") PROXYPWD <- readline(prompt = "password for proxyserver: ")
    }
    wwl[["PROXY"]] <- PROXY
    wwl[["PROXYPWD"]] <- PROXYPWD
  }
  opt <- wwl$KLIMAAT
  KLIMAAT <- get_record(text = text, item = "KLIMAAT", opt = opt)
  wwl[["KLIMAAT"]] <- KLIMAAT
  if (KLIMAAT == "__") opt <- wwl[[str_c("PERIODE_", wwl$DATABASE)]]
  if (KLIMAAT == "Wh") opt <- wwl$PERIODE_WH
  PERIODE <- get_record(text = text, item = "PERIODE", opt = opt)
  wwl[["PERIODE"]] <- PERIODE
  EENHEID <- get_record(text = text, item = "EENHEID", opt = c("cm-mv", "cm+mv", "m-mv", "m+mv"))
  wwl[["EENHEID"]] <- EENHEID
  FORMAAT <- get_record(text = text, item = "FORMAAT", opt = c("Tabel", "Shape", "Raster"))
  wwl[["FORMAAT"]] <- FORMAAT

  # in case of 'Tabel'
  if (FORMAAT == "Tabel") {
    TABEL <- get_record(text = text, item = "TABEL")
    wwl[["TABEL"]] <- TABEL
    if (!controlR::file_exists(file = wwl$TABEL)) stop()
  }

  # in case of 'Shape'
  if (FORMAAT == "Shape") {
    SHAPE <- get_record(text = text, item = "SHAPE")
    wwl[["SHAPE"]] <- SHAPE
    if (!file_exists(file = wwl$SHAPE)) stop()
  }

  # in case of 'Raster'
  if (FORMAAT == "Raster") {

    # set filename rasters
    item <- wwl$ITEMINP
    for (s_item in item) {
      FILE <- get_record(text = text, item = toupper(s_item))
      wwl[[s_item]] <- FILE
      if (is_numeric(text = FILE)) {
        if (s_item %in% c("ghg", "glg")) stop("GHG or GLG should be layers!")
        wwl[[s_item]] <- as.numeric(FILE)
      } else {
        if (!file_exists(file = FILE)) stop()
      }
      FILE <- NULL
    }
  }

  # set crop-prices
  VALUE <- get_record(text = text, item = "VEM" , item_exists = FALSE)
  if (!is.null(VALUE)) wwl$euro_vem <- VALUE
  VALUE <- get_record(text = text, item = "DVE" , item_exists = FALSE)
  if (!is.null(VALUE)) wwl$euro_dve <- VALUE

  for (cropname in wwl$cropinfo$cropname[!is.na(wwl$cropinfo$euro)]) {
    VALUE <- get_record(text = text, item = toupper(cropname), item_exists = FALSE)
    if (!is.null(VALUE)) wwl$cropinfo$euro[wwl$cropinfo$cropname == cropname] <- VALUE
  }

  # set output
  item <- toupper(wwl$ITEMOUT)
  item_out <- rep(x = TRUE, times = length(item))
  for (rec in 1:length(item)) {
    VALUE <- get_record(text = text, item = item[rec] , opt = c("Yes", "No"), item_exists = FALSE)
    if (!is.null(VALUE)) {
      if (VALUE == "No") item_out[rec] <- FALSE
    }
  }
  if (all(!item_out)) stop("No output variables selected!")
  wwl$sel_ITEMOUT <- wwl$ITEMOUT[item_out]

  # ---- return of procedure ----

  return(wwl)
}

#' Load wwl input
#'
#' @param wwl object. Watervision agriculture object.
#' @importFrom utils read.table
#' @importFrom stringr str_c
#' @importFrom readr read_csv
#' @importFrom fs path_file path_ext
#' @importFrom sf read_sf st_geometry st_drop_geometry
#' @importFrom ascR read_asc get_head_asc get_data_asc
#' @importFrom idfR read_idf get_head_idf get_data_idf
#' @importFrom tibble as_tibble add_column
#' @importFrom dplyr inner_join select
#' @importFrom controlR is_numeric
#' @return Watervision agriculture object.
#' @keywords internal
read_wwl_input <- function(wwl) {

  # ---- main part of procedure ----

  # load table
  if (wwl$FORMAAT == "Tabel") {
    message(str_c("reading file: ", path_file(wwl$TABEL)))
    wwl$data <- suppressMessages(read_csv(file = wwl$TABEL, progress = FALSE, lazy = FALSE))
  }

  # load shape
  if (wwl$FORMAAT == "Shape") {
    message(str_c("reading file: ", path_file(wwl$SHAPE)))
    shp <- read_sf(dsn = wwl$SHAPE)
    wwl$geometry <- st_geometry(shp)
    wwl$data <- st_drop_geometry(shp)
  }

  # load raster
  if (wwl$FORMAAT == "Raster") {

    first <- TRUE

    item <- wwl$ITEMINP
    for (s_item in item) {

      if (is_numeric(text = wwl[[s_item]])) {

        dat <- add_column(dat, value = wwl[[s_item]])
        names(dat)[match(x = "value", table = names(dat))] <- s_item

      } else {

        ext <- tolower(path_ext(wwl[[s_item]]))
        if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(wwl[[s_item]]), "'"))

        message(str_c("reading file: ", path_file(wwl[[s_item]])))

        if (first) {

          first         <- FALSE

          # save extent
          wwl$ext <- ext

          # load idf or asc
          if (ext == "idf") {
            head <- get_head_idf(file = wwl[[s_item]])
            lyr <- read_idf(file = wwl[[s_item]])
          } else {
            head <- get_head_asc(file = wwl[[s_item]])
            lyr <- read_asc(file = wwl[[s_item]])
          }
          dat <- lyr$data[lyr$data$value != lyr$nodata, ]
          names(dat) <- c("col", "row", s_item)

          # add coordinates
          dat <- add_column(dat, x_crd = lyr$xmin + (0.5 * lyr$dx) + (dat$col - 1) * lyr$dx)
          dat <- add_column(dat, y_crd = lyr$ymax - (0.5 * lyr$dy) - (dat$row - 1) * lyr$dy)

          # save geometry
          wwl$head <- head

        } else {

          # add idf or asc
          if (ext == "idf") {
            dat <- add_column(dat, value = get_data_idf(file = wwl[[s_item]], x_crd = dat$x_crd, y_crd = dat$y_crd))
          } else {
            dat <- add_column(dat, value = get_data_asc(file = wwl[[s_item]], x_crd = dat$x_crd, y_crd = dat$y_crd))
          }
          dat <- dat[dat$value != lyr$nodata, ]
          names(dat)[match(x = "value", table = names(dat))] <- s_item

          # check join
          if (nrow(dat) == 0) stop(str_c("\nonly NoData after merging '", path_file(wwl[[s_item]]), "'"))

        }
      }
    }

    dat <- dplyr::select(dat, -"x_crd", -"y_crd")
    wwl$data <- dat

  }

  # check columns
  item <- wwl$ITEMINP
  s_item <- item[!item %in% names(wwl$data)]
  if (length(s_item) != 0) stop(str_c("\nMissing column in data '",s_item,"'"))

  # ---- return of procedure ----

  return(wwl)
}

#' Check wwl input
#'
#' @param wwl object. Watervision agriculture object.
#' @importFrom utils head
#' @importFrom stringr str_c
#' @importFrom tibble add_column
#' @importFrom dplyr select
#' @return Watervision agriculture object.
#' @keywords internal
check_wwl_input <- function(wwl) {

  # ---- initial part of procedure ----

  dat <- wwl$data

  # ---- main part of procedure ----

  # check values
  dat <- add_column(dat, return = TRUE)

  item <- wwl$ITEMINP
  for (s_item in item) {

    opt <- NULL
    if (s_item == "gewas")     opt <- wwl[[str_c("GEWAS_", wwl$DATABASE)]]
    if (s_item == "station")   opt <- wwl$STATION
    if (s_item == "bodem")     opt <- wwl[[str_c("BODEM_", wwl$DATABASE)]]
    if (s_item == "irrigatie") opt <- wwl$IRRIGATIE
    if (s_item == "zoutconc")  opt <- wwl[[str_c("ZOUTCONC_", wwl$DATABASE)]]

    if (!is.null(opt)) {
      values <- dat[,s_item, drop = TRUE]
      dat$return[!values %in% opt] <- FALSE

      values <- unique(values)
      s_values <- values[!values %in% opt]
      if (length(s_values) != 0) {
        message(str_c("WARNING wrong value in column ", s_item,": '", str_c(sort(head(s_values)), collapse = "' '"), "'", ifelse(length(s_values) > 5, " '...'", "")))
      }
    }
  }

  # check if irrigation is combined with salinity (1.0.0 and 1.1.0)
  opt <- wwl[[str_c("GEWAS_IRRIGATIE_", wwl$DATABASE)]]
  if (wwl$DATABASE < "2.0.0") {
    rec <- !dat$gewas %in% opt & dat$irrigatie == 1 & dat$return
    if (!all(!rec)) {
      dat$return[rec] <- FALSE
      crp <- wwl$cropinfo$cropname[wwl$cropinfo$gewas_id %in%  sort(unique(dat$gewas[rec]))]
      message(str_c("WARNING irrigation not implemented for crop: ", crp, "\n"))
    }
    rec <- !dat$gewas %in% opt & dat$irrigatie == 1 & dat$zoutconc == 0 & dat$return
    if (!all(!rec)) {
      dat$return[rec] <- FALSE
      message("WARNING irrigation should be combined with salinity concentration")
    }
  }

  # save user input
  dat <- add_column(dat, gewas_user = dat$gewas)
  dat <- add_column(dat, ghg_user = dat$ghg)
  dat <- add_column(dat, glg_user = dat$glg)

  # set code reference crop
  dat$gewas <- wwl$cropinfo$crop_id[match(x = dat$gewas, table = wwl$cropinfo$gewas_id)]

  # convert unit (cm-mv)
  if (wwl$EENHEID != "cm-mv") {
    fact <- ifelse(wwl$EENHEID == "m-mv", 100.0, ifelse(wwl$EENHEID == "m+mv", -100.0, -1.0))
    dat[ ,c("ghg", "glg")] <- dat[ ,c("ghg", "glg")] * fact
  }

  # check statistics groundwaterlevels
  rec <- dat$ghg > dat$glg
  if (!all(!rec)) {
    dat$return[rec] <- FALSE
    message(str_c("WARNING check statistics groundwaterlevels; ghg decends below glg"))
  }

  # check number of records
  if (all(!dat$return)) {
    stop("\n!!! no records left to analyse !!!")
  }

  # check limits groundwaterlevels
  dat$ghg <- ifelse(dat$ghg < 0.0, 0.0, dat$ghg)
  dat$ghg <- ifelse(dat$ghg > 300.0, 300.0, dat$ghg)
  dat$glg <- ifelse(dat$glg < 0.0, 0.0, dat$glg)
  dat$glg <- ifelse(dat$glg > 300.0, 300.0, dat$glg)

  # set periode, klimaat and versie
  dat <- add_column(dat, periode = wwl$PERIODE, klimaat = wwl$KLIMAAT, versie = wwl$DATABASE)

  # ---- return of procedure ----

  wwl$data <- dat
  return(wwl)
}

#' Run wwl
#'
#' @param wwl object. Watervision agriculture object.
#' @importFrom apiwwl query_wwldb
#' @importFrom tibble add_column
#' @importFrom dplyr %>% select rename if_else mutate mutate_at
#' @importFrom progress progress_bar
#' @return Watervision agriculture object.
#' @keywords internal
run_wwl <- function(wwl) {

  # ---- initial part of procedure ----

  gewas <- dm <- euro <- NULL
  ghg <- glg <- periode <- klimaat <- versie <- NULL
  gewas_user <- ghg_user <- glg_user <- NULL
  hrvpotbio <- hrvpotvem <- hrvpotdve <- hrvpoteur <- NULL
  dmgind <- dmgdir <- dmgdry <- dmgwet <- dmgsol <- NULL

  dat <- wwl$data

  rec <- dat$return
  clm <- c("versie", "klimaat", "periode", "station", "bodem", "gewas", "irrigatie", "zoutconc", "glg", "ghg")
  hrv <- c("hrvpotbio", "hrvpotvem", "hrvpotdve")
  dmg <- c("dmgind", "dmgdry", "dmgwet", "dmgsol")

  # set reference points
  ghg_min <- get_floor(value = dat$ghg[rec], stepsize = 10.0, max_value = 300.0)
  glg_min <- get_floor(value = dat$glg[rec], stepsize = 10.0, max_value = 300.0)
  ghg_max <- get_ceiling(value = dat$ghg[rec], stepsize = 10.0, max_value = 300.0)
  glg_max <- get_ceiling(value = dat$glg[rec], stepsize = 10.0, max_value = 300.0)

  # set weight reference points
  weight <- list()
  CONSTANTE <- 1 / ((ghg_max - ghg_min) * (glg_max - glg_min))
  weight$ll <- CONSTANTE * (ghg_max - dat$ghg[rec]) * (glg_max - dat$glg[rec])
  weight$lu <- CONSTANTE * (ghg_max - dat$ghg[rec]) * (dat$glg[rec] - glg_min)
  weight$ru <- CONSTANTE * (dat$ghg[rec] - ghg_min) * (dat$glg[rec] - glg_min)
  weight$rl <- CONSTANTE * (dat$ghg[rec] - ghg_min) * (glg_max - dat$glg[rec])


  # ---- main part of procedure ----

  # get WWL results
  pb <- progress_bar$new(total = 4, format = "- download results... :percent", clear = TRUE)
  first <- TRUE
  for (LU in c("l","u")) {
    if (LU == "l") {
      dat$glg[rec] <- glg_min
    } else {
      dat$glg[rec] <- glg_max
    }
    for (LR in c("l","r")) {
      if (LR == "l") {
        dat$ghg[rec] <- ghg_min
      } else {
        dat$ghg[rec] <- ghg_max
      }

      if (is.null(wwl$PROXY)) {
        if (is.null(wwl$URL)) {
          dat_tmp <- query_wwldb(x = dat[rec, clm, drop = TRUE])
        } else {
          dat_tmp <- query_wwldb(x = dat[rec, clm, drop = TRUE], url = wwl$URL)
        }
      } else {
        dat_tmp <- query_wwldb(x = dat[rec, clm, drop = TRUE], proxy = wwl$PROXY, proxyuserpwd = wwl$PROXYPWD)
      }

      # replace missing values
      dat_tmp[is.na(dat_tmp$dmgind) |  dat_tmp$dmgind == -999, dmg] <- NA

      # multiply damage by weight
      dat_tmp[, dmg] <- dat_tmp[, dmg] * weight[str_c(LR,LU)]

      # store results
      if (first) {
        first <- FALSE
        dat_tmp[is.na(dat_tmp$hrvpotbio) |  dat_tmp$hrvpotbio == -999, c("hrvpotbio", "hrvpotvem", "hrvpotdve")] <- NA
        dat_tmp[is.na(dat_tmp$hrvpotvem) |  dat_tmp$hrvpotvem == -999, c("hrvpotvem", "hrvpotdve")] <- NA
        dat_dmg <- dat_tmp
      } else {
        dat_dmg[, dmg] <- dat_dmg[, dmg] + dat_tmp[, dmg]
      }

      # set progress
      pb$tick()

    }
  }
  message("- download results... : done")

  # add totals
  dat_dmg <- dat_dmg %>%
    mutate(
      dmgdir = dmgdry + dmgwet + dmgsol,
      dmgtot = dmgind + dmgdir
    )

  # combine datasets
  clm <- c("hrvpotbio", "hrvpotvem", "hrvpotdve", "dmgtot", "dmgind", "dmgdir", "dmgdry", "dmgwet", "dmgsol")
  dat <- dat %>%
    add_column(
      hrvpotbio = NA_integer_, hrvpotvem = NA_integer_, hrvpotdve = NA_integer_, hrvpoteur = NA_real_,
      dmgtot = NA_real_, dmgind = NA_real_, dmgdir = NA_real_, dmgdry = NA_real_, dmgwet = NA_real_, dmgsol = NA_real_
      )
  dat[rec, clm] <- dat_dmg[, clm]

  # reset user info
  dat <- dat %>%
    select(-gewas, -ghg, -glg, -return, -periode, -klimaat, -versie) %>%
    rename(gewas = gewas_user, ghg = ghg_user, glg = glg_user)

  # calculate economic potential yield
  forage <- wwl$cropinfo$gewas_id[is.na(wwl$cropinfo$euro)]
  drymatter <- wwl$cropinfo$gewas_id[!is.na(wwl$cropinfo$euro)]
  dat <- dat %>%
    mutate(
      dm = if_else(gewas %in% drymatter, wwl$cropinfo$dm[match(x = gewas, table = wwl$cropinfo$gewas_id)], NA_real_),
      euro = if_else(gewas %in% drymatter, wwl$cropinfo$euro[match(x = gewas, table = wwl$cropinfo$gewas_id)], NA_real_),
      hrvpoteur = if_else(gewas %in% forage, hrvpotvem * wwl$euro_vem + hrvpotdve * wwl$euro_dve, if_else(gewas %in% drymatter, hrvpotbio / dm * euro, hrvpoteur))
    ) %>%
    select(-dm, -euro)

  # round yield at zero digits
  dat <- dat %>%
    mutate_at(c("hrvpotbio", "hrvpoteur", "hrvpotvem", "hrvpotdve"), round, digit = 0) %>%
    mutate_at(c("dmgtot", "dmgind", "dmgdir", "dmgdry", "dmgwet", "dmgsol"), round, digit = 1)

  # ---- return of procedure ----

  wwl$data <- dat
  return(wwl)
}

#' Write output wwl
#'
#' @param wwl object. Watervision Agriculture object.
#' @importFrom utils write.table
#' @importFrom stringr str_c
#' @importFrom tibble add_column
#' @importFrom dplyr select all_of
#' @importFrom readr write_csv
#' @importFrom sf write_sf st_set_geometry
#' @importFrom idfR write_idf
#' @importFrom ascR write_asc
#' @keywords internal
write_wwl_output <- function(wwl) {

  # ---- initial part of procedure ----

  dat <- wwl$data

  # ---- main part of procedure ----

  # select columns for output
  if (wwl$FORMAAT == "Tabel" | wwl$FORMAAT == "Shape") {
    item <- wwl$ITEMOUT[!wwl$ITEMOUT %in% wwl$sel_ITEMOUT]
    dat <- dat %>%
      select(-all_of(item))
  }

  item <- wwl$sel_ITEMOUT

  # write table
  if (wwl$FORMAAT == "Tabel") {
    file <- str_c(wwl$DIROUT, "/", gsub(x = path_file(wwl$TABEL), pattern = ".csv", replacement =str_c("-", wwl$KLIMAAT, "-", tolower(wwl$PERIODE), ".csv")))
    message(str_c("writing file: ", path_file(file)))
    write_csv(x = dat, file = file, progress = FALSE, quote = "none")
  }

  # write shape
  if (wwl$FORMAAT == "Shape") {
    for (s_item in item) dat[is.na(dat[, s_item]),s_item] <- -99
    shp <- st_set_geometry(x = dat, value = wwl$geometry)
    file <- str_c(wwl$DIROUT, "/", gsub(x = path_file(wwl$SHAPE), pattern = ".shp", replacement = str_c("-", wwl$KLIMAAT, "-", tolower(wwl$PERIODE))))
    message(str_c("writing file: ", path_file(file)))
    write_sf(obj = shp, dsn = file, driver = "ESRI Shapefile")
  }

  # write raster
  if (wwl$FORMAAT == "Raster") {

    ext <- wwl$ext
    for (s_item in item) {

      # set value raster
      lyr <- wwl$head
      lyr$data <- dat[, c("col", "row", s_item)]
      names(lyr$data) <- c("col", "row", "value")

      # write raster
      file <- str_c(wwl$DIROUT, "/", s_item, "-", wwl$KLIMAAT, "-", tolower(wwl$PERIODE), ".", ext)
      message(str_c("writing file: ", file))
      if (ext == "idf") {
        write_idf(file = file, idf = lyr)
      } else {
        write_asc(file = file, asc = lyr)
      }

    }
  }
}

#' wwl-tabel
#'
#' @param file character string. Name of controlfile.
#' @importFrom stringr str_c
#' @importFrom apiwwl get_version
#' @export wwl_tabel
#' @examples
#' # specify controlfile
#' file <- system.file("extdata/control.inp", package = "WWLtabel")
#'
#' # run Watervision Agriculture (do not run!)
#' # wwl_tabel(file = file)
wwl_tabel <- function(file) {

  # ---- main part of procedure ----

  # load wwl settings
  message("\nLoad control...")
  wwl <- load_wwl_settings(file = file)

  # write version
  message("\nVersion control...")
  message("- WWL-tabel: ",read.dcf(file = system.file("DESCRIPTION", package = "WWLtabel"),fields = "Version"))
  message(str_c("- Database: ",wwl$DATABASE))
  if (max(get_version()) > wwl$DATABASE) message(str_c("WARNING update of WWL-database available: '", max(get_version(), "'")))

  # read wwl input
  message("\nLoad input...")
  wwl <- read_wwl_input(wwl = wwl)

  # check wwl input
  message("\nCheck input...")
  wwl <- check_wwl_input(wwl = wwl)

  # run wwl
  message("\nSet crop response...")
  wwl <- run_wwl(wwl = wwl)

  # write output wwl
  message("\nWrite output...")
  write_wwl_output(wwl = wwl)
}
