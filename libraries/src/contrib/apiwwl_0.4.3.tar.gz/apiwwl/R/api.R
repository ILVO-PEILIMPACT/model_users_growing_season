globalVariables(".")



#' Divide Tibble into Chunks
#'
#' @param x a \code{tibble}
#' @param size chunksize (\code{integer})
chunkify <- function(x, size = 10000L) {
    n_records <- nrow(x)
    n_chunks <- (n_records %/% size) + ((n_records %% size) > 0L)
    split(x, rep(1:n_chunks, each = size, length.out = n_records))
}



#' Convert Table to Queries
#'
#' @param x a \code{tibble}
#'
#' @return a character vector containing queries in JSON-format
#'
#' @importFrom jsonlite toJSON
querify <- function(x) {
    "queries=" %>%
        paste0(
            x %>%
                toJSON)
}



#' Post Query
#'
#' @param x a \code{tibble}, where each row is a query
#' @param url location where the WWL-database resides.
#' @param \dots further arguments passed to or from other methods
#'
#' @details Examples of further arguments in \code{\dots} are
#'   \code{proxy}, i.e., the url of the proxyserver including port specification
#'   (e.g., "http://proxyserver:8080") and corresponding \code{proxyuserpwd}, i.e., the
#'   user password for the proxyserver. See \code{\link{curl_options}} for details.
#'
#' @return a \code{tibble} containing the results of the queries in \code{x}.
#'
#' @seealso \code{\link{query_wwldb}}
#'
#' @importFrom curl new_handle curl_fetch_memory
#' @importFrom jsonlite parse_json
#' @importFrom dplyr as_tibble select
#' @importFrom purrr chuck
#' @importFrom tidyselect contains
post <- function(x, url = "https://waterwijzerlandbouw.wur.nl/query-wdb.php", ...) {
    url %>%
        curl_fetch_memory(new_handle(postfields = querify(x), ...)) %>%
        chuck("content") %>%
        rawToChar %>%
        parse_json(simplifyVector = TRUE) %>%
        as_tibble %>%
        select(-contains("error_flag"))
}



#' Query Water Vision Agriculture Database
#'
#' Generic function for querying the Water Vision Agriculture Database.
#'
#' @param x query, formatted as a \code{tibble}.
#' @param \dots further arguments passed to or from other methods like \code{\link{post}}.
#' @export
query_wwldb <- function(x, ...) {
    UseMethod("query_wwldb", x)
}



#' @describeIn query_wwldb query via a tibble/data_frame.
#'
#' @importFrom purrr map_df
#' @importFrom dplyr "%>%" mutate_if mutate_all
#' @export
#' @examples
#'
#' \dontrun{
#'
#' library(dplyr)
#'
#' # construct queries (should be a tibble)
#' query <- tribble(
#'     ~bodem, ~gewas, ~ghg, ~glg,  ~klimaat, ~station,  ~periode, ~versie,
#'     "101",     19,    0,    0,      "__",      235,    "1981",  "1.0.0",
#'     "101",     19,    0,   10,      "__",      235,    "1981",  "1.0.0",
#'     "101",     19,   10,   10,      "__",      235,    "1981",  "1.0.0",
#'     "101",     19,    0,   20,      "__",      235,    "1981",  "1.0.0",
#'     "101",     19,   10,   20,      "__",      235,    "1981",  "1.0.0",
#'     "101",     19,   20,   20,      "__",      235,    "1981",  "1.0.0"
#' )
#'
#' # query database
#' query_wwldb(query)
#'
#' }
query_wwldb.tbl_df <- function(x, ...) {
    x %>%
        mutate_if(is.double, signif) %>%
        mutate_all(as.character) %>%
        chunkify %>%
        map_df(post, ...)
}



#' Version Waterwijzer Landbouw Database
#'
#' @return available version numbers (\code{character})
#'
#' @export
get_version <- function() {
    return(c("2.0.0", "3.0.0"))
}
