#' API WaterVision Agriculture Database
#'
#' Application Programming Interface (API) to the
#' WaterVision Agriculture (Waterwijzer Landbouw) database.
#'
#' @author Dennis Walvoort (Wageningen Environmental Research)
#'
"_PACKAGE"
