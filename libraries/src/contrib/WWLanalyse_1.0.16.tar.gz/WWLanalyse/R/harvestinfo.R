#' Create harvest settings
#'
#' @param file_swp character string, name of (SWAP)file.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c str_which str_trim str_replace_all
#' @importFrom fs path_package path_file
#' @importFrom readr read_rds read_lines write_lines
#' @importFrom SWAPtools get_settings_SWAP get_variable_SWAP set_template_SWAP set_switch_SWAP set_variable_SWAP
#' @importFrom dplyr filter select slice all_of
#' @importFrom tibble deframe
#' @keywords internal
#' @export create_harvestinfo
create_harvestinfo <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  crop_id <- cropfile <- NULL

  # set optional arguments
  opt_param <- c("run_info", "soil_id", "type", "settings_wwl", "variable_wwl", "variable_swap", "sign_open", "sign_close", "quiet")
  run_info <- soil_id <- type <- settings_wwl <- variable_wwl <- variable_swap <- sign_open <- sign_close <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", paste(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(sign_open)) sign_open <- "\\{\\{"
  if (is.null(sign_close)) sign_close <- "\\}\\}"
  if (is.null(quiet)) quiet <- TRUE

  template <- str_c(path_package(package = "WWLanalyse"), "/template/INDIRECT.template")

  # ---- main part of procedure ----

  # set modus (extract settings from database or settings are based and soil physical unit)
  if (!is.null(soil_id) & !is.null(run_info)) stop("either 'run_info' or 'soil_id' should be specified")
  if (is.null(soil_id) & is.null(run_info)) stop("'run_info' or 'soil_id' should be specified")
  if (!is.null(soil_id) & is.null(type)) stop("'type' should be specified; options: 'BOFEK2012', 'BOFEK2020' or 'BODEM'")
  if (!is.null(type)) {
    if (!type %in% c("BOFEK2012", "BOFEK2020", "BODEM")) stop("item: 'type' should have one of the following options: 'BOFEK2012' 'BOFEK2020' 'BODEM'")
  }
  modus <- ifelse(is.null(run_info), "soilunit", "database")

  # set run_directory
  dir_run <- path_dir(file_swp)

  variable <- c("CROPROTATION::CROPFIL")
  settings <- get_settings_SWAP(file = file_swp, variable = variable, variable_swap = variable_swap)

  # loop over crops
  cropinfo <- settings_wwl$cropinfo
  cropfil <- unique(settings$CROPFIL)
  cropfil <- cropfil[cropfil %in% cropinfo$cropfile]
  for (s_cropfil in cropfil) {

    croptype <- cropinfo %>%
      filter(cropfile == s_cropfil) %>%
      select(croptype) %>%
      slice(1) %>%
      deframe()

    # only in case of WOFOST or FIXED crop module
    if (croptype %in% 1:2) {

      if (modus == "database") {

        # set template
        tmplt <- set_template_SWAP(template = template, run_info = run_info, variable_swap = variable_wwl, quiet = quiet)

      } else {

        # set soil and crop
        soil <- soil_id
        crop <- cropinfo %>%
          filter(cropfile == s_cropfil) %>%
          select(crop_id) %>%
          slice(1) %>%
          deframe()

        # extract harvestinfo
        if (type == "BOFEK2012") {
          harvestinfo <- settings_wwl$harvestinfo_BOFEK2012 %>%
            filter(soil_id == all_of(soil) & crop_id == all_of(crop))
        }
        if (type == "BOFEK2020") {
          harvestinfo <- settings_wwl$harvestinfo_BOFEK2020 %>%
            filter(soil_id == all_of(soil) & crop_id == all_of(crop))
        }
        if (type == "BODEM") {
          harvestinfo <- settings_wwl$harvestinfo_BODEM %>%
            filter(soil_id == all_of(soil) & crop_id == all_of(crop))
        }

        # load template
        tmplt <- read_lines(file = template, lazy = FALSE)

        # fill template
        variable <- get_variable_SWAP(tmplt)
        done <- ifelse(is.null(variable), TRUE, FALSE)
        while (!done) {

          done <- TRUE

          for (s_variable in variable) {

            # extract variable
            s_var_WWL <- variable_wwl[[s_variable]]
            if (is.null(s_var_WWL)) stop(str_c("unknown variable found in template '", s_variable,"'"))
            format <- s_var_WWL$format

            # load settings
            value <- harvestinfo %>% select(all_of(s_variable)) %>% deframe()

            # in case of switch
            if (format == "switch") {
              done <- FALSE
              tmplt <- set_switch_SWAP(tmplt = tmplt, switch = s_variable, value = value, variable_swap = variable_wwl, sign_open = sign_open, sign_close = sign_close)
            }

            # in case of variable
            if (format == "float") {
              tmplt <- set_variable_SWAP(tmplt = tmplt, variable = s_variable, value = value, variable_swap = variable_wwl, sign_open = sign_open, sign_close = sign_close)
            }
          }

          # update variables
          variable <- get_variable_SWAP(tmplt = tmplt, sign_open = sign_open, sign_close = sign_close)
        }
      }

      file_crp <- str_c(dir_run,"/", s_cropfil,".wwl")
      if (!quiet) message(str_c("writing file: ", path_file(file_crp)))
      write_lines(x = tmplt, file = file_crp)
    }

  }
}
