#' Get DVE (darm verteerbaar eiwit)
#'
#' @param SD numeric value, start of growth period in season
#' @param GD numeric value, duration of growth period from start till harvest
#' @return numeric value, DVE
#' @keywords internal
get_DVE <- function(SD, GD) {

  # ---- initial part of procedure ----

  a1 <- 129.517865100
  a2 <-  -0.057243606
  a3 <-  -0.000175911
  b1 <-   1.736203378
  b2 <-  -0.048342189
  b3 <-   0.000265867
  b4 <-  -4.24734e-07

  # ---- main part of procedure ----

  # set minimum duration of growth
  GD[GD < 10] <- 10

  # calculate DVE
  DVE <- (a1 + a2*SD + a3*SD^2) + (b1 + b2*SD + b3*SD^2 + b4*SD^3) * GD

  # ---- return of procedure ----

  return(DVE)
}

#' Get VEM (voedereenheid melk)
#'
#' @param SD numeric value, start of growth period in season
#' @param GD numeric value, duration of growth period from start till harvest
#' @return numeric value, VEM
#' @keywords internal
get_VEM <- function(SD, GD) {

  # ---- initial part of procedure ----

  a1 <- 886.8528
  a2 <- 2910.217
  b1 <- 1.218037
  b2 <- 17.55224

  # ---- main part of procedure ----

  # set minimum duration of growth
  GD[GD < 10] <- 10

  # calculate VEM
  VEM <- a1 + a2 * (365.25-SD)/SD * b1/b2 * (GD/b2)^(b1-1) * exp(-(GD/b2)^b1)

  # ---- return of procedure ----

  return(VEM)
}

#' Extract settings Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom readr read_rds
#' @importFrom dplyr %>% filter select slice
#' @importFrom tibble deframe
#' @importFrom SWAPtools get_settings_SWAP
#' @keywords internal
#' @export get_settings_WWL
get_settings_WWL <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  cropfile <- NULL

  # set optional arguments
  opt_param <- c("settings_wwl", "variable_wwl", "variable_swap", "quiet")
  settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE

  # ---- main part of procedure ----

  # set run_directory
  dir_run <- path_dir(file_swp)

  cropinfo <- settings_wwl$cropinfo
  variable <- c("OUTFIL", "TSTART", "TEND", "CROPROTATION::CROPFIL", "CROPROTATION::CROPSTART", "CROPROTATION::CROPEND", "CROPROTATION::CROPTYPE")
  settings <- get_settings_SWAP(file = file_swp, variable = variable, variable_swap = variable_swap)

  # loop over crops
  cropfile <- unique(settings$CROPFIL)
  cropfile <- unique(cropfile[cropfile %in% cropinfo$cropfile])
  for (s_cropfile in cropfile) {

    # extract croptype
    croptype <- cropinfo %>%
      filter(cropfile == s_cropfile) %>%
      select(croptype) %>%
      slice(1) %>%
      deframe()

    # in case of arable crop
    if (croptype %in% 1:2) {
      variable <- c("SWIND", "DVSHARV", "HHARV")
      file_crp <- str_c(dir_run,"/", s_cropfile,".wwl")
      settings[[s_cropfile]] <- get_settings_SWAP(file = file_crp, variable = variable, variable_swap = variable_wwl)
    }

    # in case of grass
    if (croptype == 3) {
      variable <- c("MOWREST", "SWLOSSMOW", "LOSSMOWTB::HLOSSMOW", "LOSSMOWTB::LOSSMOW")
      file_crp <- str_c(dir_run,"/", s_cropfile,".crp")
      settings[[s_cropfile]] <- get_settings_SWAP(file = file_crp, variable = variable, variable_swap = variable_swap)
    }

  }

  # ---- return of procedure ----

  return(settings)

}

#' Load data Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom lubridate as_date year month day
#' @importFrom readr read_rds
#' @importFrom dplyr %>% rename mutate select if_else all_of
#' @importFrom SWAPtools read_csv_SWAP
#' @keywords internal
load_data_WWL <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  GWL <- datetime <- NULL

  # set optional arguments
  opt_param <- c("settings", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  settings <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE
  if (is.null(settings)) settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)


  # ---- main part of procedure ----

  # set run_directory
  dir_run <- path_dir(file_swp)

  # assign settings swp-file
  OUTFIL <- CROPFIL <- NULL
  for (name in c("OUTFIL", "CROPFIL")) assign(name, settings[[name]])

  # extract name of crop
  cropinfo <- settings_wwl$cropinfo
  cropfile <- cropinfo$cropfile
  cropfile <- unique(cropfile[cropfile %in% unique(CROPFIL)])
  croptype <- cropinfo$croptype[cropinfo$cropfile %in% cropfile]
  harvest <- cropinfo$harvest[cropinfo$cropfile %in% cropfile]

  # set variable to extract
  variable <- c("GWL", "H[-15.0]", "TPOT", "TACT", "TREDWET", "TREDDRY", "TREDSOL")
  if (3 %in% croptype) variable <- c(variable, "TSUM", "PGRASSDM", "PMOWDM", "PGRAZDM", "PLOSSDM", "GRASSDM", "MOWDM", "GRAZDM", "LOSSDM")
  if (2 %in% croptype & "WDM" %in% harvest) variable <- c(variable, "DVS", "CPWDM", "CWDM")
  if (2 %in% croptype & "WSO" %in% harvest)  variable <- c(variable, "DVS", "CPWSO", "CWSO")
  if (1 %in% croptype) variable <- c(variable, "DVS")
  variable <- unique(variable)

  # load swap results
  file <- str_c(dir_run, "/", OUTFIL, "_output.csv")
  data <- read_csv_SWAP(file = file, variable = variable, timestamp = FALSE, quiet = quiet) %>%
    rename(H = all_of("H[-15.0]")) %>%
    mutate(
      GWL = if_else(GWL > 900, NA_real_, GWL),
      date = as_date(datetime),
      year = year(datetime),
      month = month(datetime),
      day = day(datetime)
    ) %>%
    select(-datetime)

  # ---- return of procedure ----

  return(data)
}

#' Add growth season to data Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom lubridate year
#' @importFrom readr read_rds
#' @importFrom dplyr rename mutate select filter if_else all_of slice slice_min slice_max min_rank
#' @importFrom tibble deframe
#' @keywords internal
add_growthseason <- function(file_swp, ...) {

  DVS <- H <- TSUM <- NULL
  date <- month <- crop <- season <- full_season <- temp <- NULL

  # ---- initial part of procedure ----

  # set optional arguments
  opt_param <- c("year_start", "year_end", "data", "settings", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- data <- settings <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE
  if (is.null(settings)) settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  if (is.null(data)) data <- load_data_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)


  # ---- main part of procedure ----

  # assign settings swp-file
  OUTFIL <- TSTART <- TEND <- CROPFIL <- CROPSTART <- CROPEND <- CROPTYPE <- NULL
  for (name in c("OUTFIL", "TSTART", "TEND", "CROPFIL", "CROPSTART", "CROPEND", "CROPTYPE")) assign(name, settings[[name]])

  # set directory
  dir_run <- path_dir(file_swp)

  # set period to analyse
  if (is.null(year_start)) year_start <- year(TSTART)
  if (is.null(year_end)) year_end <- year(TEND)

  # ---- main part of procedure ----

  # add columns growth season
  data <- data %>%
    mutate(crop = NA_character_, season = 0)

  # extract crops watervision agriculture
  cropinfo <- settings_wwl$cropinfo
  cropfile <- cropinfo$cropfile
  cropfile <- unique(cropfile[cropfile %in% unique(CROPFIL)])

  # loop over crops
  for (s_cropfile in cropfile) {

    # set season full
    data <- data %>%
      mutate(full_season = 0)

    # select dates
    for (rec in which(CROPFIL %in% s_cropfile & year(CROPEND) >= year_start & year(CROPEND) <= year_end)) {
      data <- data %>%
        mutate(full_season = if_else(date >= CROPSTART[rec] & date <= CROPEND[rec], year(CROPEND[rec]), full_season))
    }

    # extract croptype
    croptype <- cropinfo %>%
      filter(cropfile == s_cropfile) %>%
      select(croptype) %>%
      slice(1) %>%
      deframe()

    # select growth period in case of GRASS
    if (croptype == 3) {

      # determine start of crop growth
      cropstart <- data %>%
        filter(TSUM >= 200 & full_season > 0) %>%
        group_by(full_season) %>%
        slice(1) %>%
        ungroup() %>%
        select(date) %>%
        deframe()

      # determine date of harvest
      cropend <- data %>%
        filter(TSUM >= 200 & month < 11 & full_season > 0) %>%
        group_by(full_season) %>%
        slice_max(date) %>%
        ungroup() %>%
        select(date) %>%
        deframe()
    }

    # select growth period in case of WOFOST or FIXED
    if (croptype %in% 1:2) {

      # assign settings crp-file
      crop_settings <- settings[[s_cropfile]]
      SWIND <- DVSHARV <- HHARV <- NULL
      for (name in c("SWIND", "DVSHARV", "HHARV")) assign(name, crop_settings[[name]])

      # determine start of crop growth
      cropstart <- data %>%
        filter(DVS > 0 & full_season > 0) %>%
        group_by(full_season) %>%
        slice(1) %>%
        ungroup() %>%
        select(date) %>%
        deframe()

      # determine date of harvest
      cropend <- data %>%
        filter(DVS > 0 & full_season > 0) %>%
        group_by(full_season) %>%
        slice_max(date) %>%
        ungroup() %>%
        select(date) %>%
        deframe()
      if (SWIND == 1) {
        cropend <- data %>%
          mutate(DVS = if_else(date %in% cropend, 3.0, DVS)) %>%
          filter(DVS >= DVSHARV & full_season > 0) %>%
          mutate(temp = pmax(0, H - all_of(HHARV))) %>%
          group_by(full_season) %>%
          filter(min_rank(temp) == 1) %>%
          slice_max(date) %>%
          ungroup() %>%
          select(date) %>%
          deframe()
      }
    }

    # set season and harvest
    for (rec in 1:length(cropstart)) {
      data <- data %>%
        mutate(
          crop = if_else(date >= cropstart[rec] & date <= cropend[rec], s_cropfile, crop),
          season = if_else(date >= cropstart[rec] & date <= cropend[rec], year(cropend[rec]), season)
        )
    }
  }

  # clean data
  data <- data %>%
    select(-full_season)

  # ---- return of procedure ----

  return(data)
}

#' Extract harvest Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stats approx
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom lubridate year
#' @importFrom readr read_rds
#' @importFrom dplyr %>% rename mutate select filter if_else all_of slice_min slice_max slice lag group_by ungroup summarise arrange left_join
#' @importFrom tibble deframe
#' @keywords internal
extract_harvest <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  CPWDM <- CWDM <- CPWSO <- CWSO <- PGRASSDM <- GRASSDM <- PMOWDM <- MOWDM <- PGRAZDM <- GRAZDM <- PLOSSDM <- LOSSDM <- H <- NULL
  phrv_dm <- hrv_dm <- ploss_dm <- loss_dm <- phrv_kdve <- hrv_kdve <- phrv_kvem <- hrv_kvem <- NULL
  season <- year <- crop <- NULL
  date <- datestart <- NULL

  # set optional arguments
  opt_param <- c("year_start", "year_end", "data", "settings", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- data <- settings <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE
  if (is.null(settings)) settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  if (is.null(data)) data <- add_growthseason(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)


  # ---- main part of procedure ----

  cropinfo <- settings_wwl$cropinfo

  # loop over crops
  db_harvest <- NULL
  cropfile <- unique(data$crop[!is.na(data$crop)])
  for (s_cropfile in cropfile) {

    # extract croptype
    croptype <- cropinfo %>%
      filter(cropfile == s_cropfile) %>%
      select(croptype) %>%
      slice(1) %>%
      deframe()

    # extract all data with selected crop
    db_tmp <- data %>%
      filter(crop == s_cropfile & season > 0)

    # extract harvest in case of GRASS
    if (croptype == 3) {

      # assign settings crp-file
      crop_settings <- settings[[s_cropfile]]
      MOWREST <- SWLOSSMOW <- HLOSSMOW <- LOSSMOW <- NULL
      for (name in c("MOWREST", "SWLOSSMOW", "HLOSSMOW", "LOSSMOW")) assign(name, crop_settings[[name]])

      # select growth period
      cropstart <- db_tmp %>%
        group_by(season) %>%
        slice_min(date) %>%
        ungroup() %>%
        select(date) %>%
        deframe()

      cropend <- db_tmp %>%
        group_by(season) %>%
        slice_max(date) %>%
        ungroup() %>%
        select(date) %>%
        deframe()

      # set harvest and losses (including last date)
      db_tmp <- db_tmp %>%
        mutate(
          ploss_dm = if_else(date %in% cropend, PLOSSDM + approx(x = HLOSSMOW, y = LOSSMOW, xout = H, rule = 2)$y * pmax(PGRASSDM - MOWREST, 0), PLOSSDM),
          phrv_dm = if_else(date %in% cropend, PMOWDM + PGRAZDM + pmax(PGRASSDM - MOWREST, 0) - approx(x = HLOSSMOW, y = LOSSMOW, xout = H, rule = 2)$y * pmax(PGRASSDM - MOWREST, 0) + 0.01, PMOWDM + PGRAZDM),
          loss_dm = if_else(date %in% cropend, LOSSDM + approx(x = HLOSSMOW, y = LOSSMOW, xout = H, rule = 2)$y * pmax(GRASSDM - MOWREST, 0), LOSSDM),
          hrv_dm = if_else(date %in% cropend, MOWDM + GRAZDM + pmax(GRASSDM - MOWREST, 0) - approx(x = HLOSSMOW, y = LOSSMOW, xout = H, rule = 2)$y * pmax(GRASSDM - MOWREST, 0) + 0.01, MOWDM + GRAZDM),
        )

      # potential harvest
      db_pot <- db_tmp %>%
        slice(which(phrv_dm != lag(phrv_dm))) %>%
        mutate(
          datestart = lag(date + 1, default = cropstart[1]),
          phrv_dm = phrv_dm - lag(phrv_dm, default = 0)
        ) %>%
        select(season, crop, datestart, date, ploss_dm, phrv_dm)

      # reset first record of each year
      if (length(cropstart) > 1) {
        idx <- which(db_pot$phrv_dm < 0)
        db_pot$datestart[idx + 1] <- cropstart[2:length(cropstart)]
        db_pot <- db_pot %>% filter(phrv_dm >= 0)
      }

      # reset startdate (in case of grazing)
      for (row in which(db_pot$date == db_pot$datestart)) db_pot$datestart[row] <- db_pot$datestart[row - 1]

      # set DVE and VEM
      db_pot <- db_pot %>%
        mutate(
          phrv_kdve = get_DVE(SD = dayyear(datestart), GD = dayyear(date) - dayyear(datestart) + 1) * 0.001 * phrv_dm,
          phrv_kvem = get_VEM(SD = dayyear(datestart), GD = dayyear(date) - dayyear(datestart) + 1) * 0.001 * phrv_dm
        ) %>%
        select(-datestart, -date) %>%
        group_by(season, crop) %>%
        summarise(
          phrv_dm = sum(phrv_dm),
          ploss_dm = sum(ploss_dm),
          phrv_kdve = sum(phrv_kdve),
          phrv_kvem = sum(phrv_kvem),
          .groups = "drop"
        )

      # actual harvest
      db_act <- db_tmp %>%
        slice(which(hrv_dm != lag(hrv_dm))) %>%
        mutate(
          datestart = lag(date + 1, default = cropstart[1]),
          hrv_dm = hrv_dm - lag(hrv_dm, default = 0)
        ) %>%
        select(season, crop, datestart, date, loss_dm, hrv_dm)

      # reset first record of each year
      if (length(cropstart) > 1) {
        idx <- which(db_act$hrv_dm < 0)
        db_act$datestart[idx + 1] <- cropstart[2:length(cropstart)]
        db_act <- db_act %>% filter(hrv_dm >= 0)
      }

      # reset startdate (in case of grazing)
      for (row in which(db_act$date == db_act$datestart)) db_act$datestart[row] <- db_act$datestart[row - 1]

      # set DVE and VEM
      db_act <- db_act %>%
        mutate(
          hrv_kdve = get_DVE(SD = dayyear(datestart), GD = dayyear(date) - dayyear(datestart) + 1) * 0.001 * hrv_dm,
          hrv_kvem = get_VEM(SD = dayyear(datestart), GD = dayyear(date) - dayyear(datestart) + 1) * 0.001 * hrv_dm
        ) %>%
        select(-datestart, -date) %>%
        group_by(season, crop) %>%
        summarise(
          hrv_dm = sum(hrv_dm),
          loss_dm = sum(loss_dm),
          hrv_kdve = sum(hrv_kdve),
          hrv_kvem = sum(hrv_kvem),
          .groups = "drop"
        )

      # combine potential and actual harvest
      db_tmp <- left_join(x = db_pot, y = db_act, by = c("season", "crop")) %>%
        rename(year = season)

    }

    # extract harvest in case of WOFOST
    if (croptype == 2) {

      if (s_cropfile == "snijmais") {

        db_tmp <- db_tmp %>%
          group_by(season) %>%
          slice_max(date) %>%
          ungroup() %>%
          select(season, crop, CPWDM, CWDM) %>%
          rename(year = season, phrv_dm = CPWDM, hrv_dm = CWDM) %>%
          mutate(
            phrv_kdve = phrv_dm * settings_wwl$dm_dve * 0.001,
            phrv_kvem = phrv_dm * settings_wwl$dm_vem * 0.001,
            ploss_dm = 0,
            hrv_kdve = hrv_dm * settings_wwl$dm_dve * 0.001,
            hrv_kvem = hrv_dm * settings_wwl$dm_vem * 0.001,
            loss_dm = 0
          )

      } else {

        db_tmp <- db_tmp %>%
          group_by(season) %>%
          slice_max(date) %>%
          ungroup() %>%
          select(season, crop, CPWSO, CWSO) %>%
          rename(year = season, phrv_dm = CPWSO, hrv_dm = CWSO) %>%
          mutate(
            phrv_kdve = 0, phrv_kvem = 0, ploss_dm = 0,
            hrv_kdve = 0, hrv_kvem = 0, loss_dm = 0
          )

      }
    }

    # set dummy harvest in case of FIXED
    if (croptype == 1) {

      db_tmp <- db_tmp %>%
        group_by(season) %>%
        slice_max(date) %>%
        ungroup() %>%
        select(season, crop) %>%
        rename(year = season) %>%
        mutate(
          phrv_dm = 0, phrv_kdve = 0, phrv_kvem = 0, ploss_dm = 0,
          hrv_dm = 0, hrv_kdve = 0, hrv_kvem = 0, loss_dm = 0
        )

    }

    # combine data
    db_harvest <- rbind(db_harvest, db_tmp)

  }

  # check missing values
  db_harvest[is.na(db_harvest)] <- 0
  db_harvest <- db_harvest %>%
    arrange(year)

  # ---- return of procedure ----

  return(db_harvest)
}

#' Extract stress Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom readr read_rds
#' @importFrom dplyr %>% rename mutate select filter if_else all_of group_by summarise
#' @keywords internal
extract_stress <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  TPOT <- TACT <- TREDDRY <- TREDWET <- TREDSOL <- NULL
  tpot <- tact <- treddry <- tredwet <- tredsol <- NULL
  crop <- season <- tred <- NULL

  # set optional arguments
  opt_param <- c("year_start", "year_end", "data", "settings", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- data <- settings <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE
  if (is.null(settings)) settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  if (is.null(data)) data <- add_growthseason(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)


  # ---- main part of procedure ----

  # aggregate transpiration reduction
  db_stress <- data %>%
    filter(season > 0) %>%
    group_by(season, crop) %>%
    summarise(
      tpot = sum(TPOT) * 10.0,
      tact = sum(TACT) * 10.0,
      tredwet = sum(TREDWET) * 10.0,
      treddry = sum(TREDDRY) * 10.0,
      tredsol = sum(TREDSOL) * 10.0,
      .groups = "drop"
    ) %>%
    mutate(
      tred = tredwet + treddry + tredsol,
      wet = if_else(tred == 0, 0, tredwet / tred * 100.0),
      dry = if_else(tred == 0, 0, treddry / tred * 100.0),
      sol = if_else(tred == 0, 0, tredsol / tred * 100.0)
    ) %>%
    rename(year = season) %>%
    select(-tred, -tredwet, -treddry, -tredsol)

  # ---- return of procedure ----

  return(db_stress)

}

#' Extract GHG and GLG Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package path_dir
#' @importFrom lubridate as_date year
#' @importFrom readr read_rds
#' @importFrom dplyr rename
#' @importFrom SWAPtools get_gxg
#' @keywords internal
extract_gxg <- function(file_swp, ...) {

  GWL <- NULL

  # ---- initial part of procedure ----

  # set optional arguments
  opt_param <- c("year_start", "year_end", "data", "settings", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- data <- settings <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE
  if (is.null(settings)) settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  if (is.null(data)) data <- load_data_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)

  # ---- main part of procedure ----

  # assign settings swp-file
  TSTART <- TEND <- NULL
  for (name in c("TSTART", "TEND")) assign(name, settings[[name]])

  # set period to analyse
  if (is.null(year_start)) year_start <- year(TSTART)
  if (is.null(year_end)) year_end <- year(TEND)
  tstart <- as_date(str_c(year_start, "-04-01"))
  tend <- as_date(str_c(year_end, "-03-31"))

  # determine GxG
  if (any(is.na(data$GWL))) {
    gxg <- c(NA_real_, NA_real_)
  } else {
    db <- data %>% rename(value = GWL)
    gxg <- get_gxg(db = db, tstart = tstart, tend = tend, min_year = 5, quiet = quiet)
  }

  # ---- return of procedure ----

  return(gxg)
}

#' Collect data of single run Watervision Agriculture
#'
#' @param file_swp character string, name of (SWAP)file
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package
#' @importFrom lubridate year
#' @importFrom readr read_rds
#' @importFrom dplyr %>% left_join
#' @keywords internal
#' @export collect_data_run
collect_data_run <- function(file_swp, ...) {

  # ---- initial part of procedure ----

  # set optional arguments
  opt_param <- c("year_start", "year_end", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE


  # ---- main part of procedure ----

  # load settings simulation
  settings <- get_settings_WWL(file_swp = file_swp, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)

  # assign settings
  TSTART <- TEND <- NULL
  for (name in c("TSTART", "TEND")) assign(name, settings[[name]])

  # set period to analyse
  if (is.null(year_start)) year_start <- year(TSTART)
  if (is.null(year_end)) year_end <- year(TEND)

  # load data simulation (and add season)
  data <- add_growthseason(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)

  # extract data
  gxg <- extract_gxg(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, data = data, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  db_stress <- extract_stress(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, data = data, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  db_harvest <- extract_harvest(file_swp = file_swp, settings = settings, year_start = year_start, year_end = year_end, data = data, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)

  # combine data
  db_plot <- left_join(x = db_stress, y = db_harvest, by = c("year", "crop")) %>%
    mutate(
      ghg = gxg[1],
      glg = gxg[2]
    )

  # ---- return of procedure ----

  return(db_plot)
}

#' Extract data of single plot Watervision Agriculture
#'
#' @param file_ind character string, name of (SWAP)file (potential growing season)
#' @param file_dir character string, name of (SWAP)file (actual growing season)
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_package
#' @importFrom readr read_rds
#' @importFrom dplyr %>% select filter rename mutate group_by summarise left_join
#' @export collect_data_plot
collect_data_plot <- function(file_ind, file_dir, ...) {

  # ---- initial part of procedure ----

  maxhrv_dm <- phrv_dm <- hrv_dm <- maxloss_dm <- ploss_dm <- loss_dm <- avgphrv <- NULL
  maxhrv_kdve <- phrv_kdve <- hrv_kdve <- maxhrv_kvem <- phrv_kvem <- hrv_kvem <- NULL
  maxtpot <- tpot <- tact <- avgtpot <- dry <- wet <- sol <- yred <- yind <- ydir <- ky <- NULL
  crop <- year <- ghg <- glg <- NULL
  hrvpotbio <- hrvpotdve <- hrvpotvem <- dmgtot <- dmgind <- dmgdir <- dmgdry <- dmgwet <- dmgsol <- NULL

  # set optional arguments
  opt_param <- c("year_start", "year_end", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE


  # ---- main part of procedure ----

  # list croptype
  cropinfo <- settings_wwl$cropinfo
  GRASS <- cropinfo$cropfile[cropinfo$croptype == 3]
  WOFOST <- cropinfo$cropfile[cropinfo$croptype == 2]
  FIXED <- cropinfo$cropfile[cropinfo$croptype == 1]

  # extract results (indirect and direct)
  db_pot <- collect_data_run(file_swp = file_ind, year_start = year_start, year_end = year_end, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet) %>%
    select(year, crop, tpot, phrv_dm, ploss_dm, phrv_kvem, phrv_kdve) %>%
    rename(maxtpot = tpot, maxhrv_dm = phrv_dm, maxloss_dm = ploss_dm, maxhrv_kvem = phrv_kvem, maxhrv_kdve = phrv_kdve)
  db_act <- collect_data_run(file_swp = file_dir, year_start = year_start, year_end = year_end, settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap, quiet = quiet)
  db <- left_join(x = db_pot, y = db_act, by = c("year", "crop"))

  # set harvest (in case of FIXED)
  if (any(db$crop %in% FIXED)) {

    # set average tpot
    db_tpot <- db %>%
      filter(crop %in% FIXED) %>%
      group_by(crop) %>%
      summarise(
        avgtpot = mean(maxtpot),
        .groups = "drop"
      ) %>%
      mutate(
        avgphrv = cropinfo$yield[match(x = crop, table = cropinfo$cropfile)],
        ky = cropinfo$ky[match(x = crop, table = cropinfo$cropfile)]
      )

    # set harvest
    db <- left_join(x = db, y = db_tpot, by = "crop") %>%
      mutate(
        maxhrv_dm = if_else(crop %in% FIXED, avgphrv * maxtpot / avgtpot, maxhrv_dm),
        phrv_dm = if_else(crop %in% FIXED, (1 - (ky * (1 - tpot / maxtpot))) * maxhrv_dm, phrv_dm),
        hrv_dm = if_else(crop %in% FIXED, (1 - (ky * (1 - tact / maxtpot))) * maxhrv_dm, hrv_dm)
      ) %>%
      select(-avgtpot, -avgphrv, -ky)

  }

  # reset potential growth depending on extra losses (in case of GRASS)
  if (any(db$crop %in% GRASS)) {
    db <- db %>%
      mutate(
        loss_dm = if_else(crop %in% GRASS, pmax(0, loss_dm - maxloss_dm), loss_dm),
        phrv_dm = if_else(crop %in% GRASS, maxhrv_dm - loss_dm, phrv_dm),
      )
  }

  # check harvest
  rec <- which(db$maxhrv_dm < db$phrv_dm)
  if (length(rec) & !quiet) message(str_c("Reset potential harvest; number of records influenced: ",length(rec)," (phrv_dm)"))
  db <- db %>% mutate(phrv_dm = if_else(maxhrv_dm < phrv_dm, maxhrv_dm, phrv_dm))
  rec <- which(db$phrv_dm < db$hrv_dm)
  if (length(rec) & !quiet) message(str_c("Reset actual harvest; number of records influenced: ",length(rec)," (hrv_dm)"))
  db <- db %>% mutate(hrv_dm = if_else(phrv_dm < hrv_dm, phrv_dm, hrv_dm))


  # set yield gap
  db <- db %>%
    mutate(
      yred = maxhrv_dm - hrv_dm,
      yind = maxhrv_dm - phrv_dm,
      ydir = phrv_dm - hrv_dm,
      dmgtot = if_else(yred > 0, yred / maxhrv_dm * 100, 0),
      dmgind = if_else(yind > 0, yind / yred * dmgtot, 0),
      dmgdir = if_else(ydir > 0, ydir / yred * dmgtot, 0),
      dmgwet = if_else(dmgdir > 0, 0.01 * wet * dmgdir, 0),
      dmgdry = if_else(dmgdir > 0, 0.01 * dry * dmgdir, 0),
      dmgsol = if_else(dmgdir > 0, 0.01 * sol * dmgdir, 0)
    ) %>%
    rename(hrvpotbio = maxhrv_dm, hrvpotvem = maxhrv_kvem, hrvpotdve = maxhrv_kdve) %>%
    select(year, crop, ghg, glg, hrvpotbio, hrvpotvem, hrvpotdve, dmgtot, dmgind, dmgdir, dmgwet, dmgdry, dmgsol)

  # ---- return of procedure ----

  return(db)
}

#' Add average results
#'
#' @param db_plot tibble, output of collect_data_plot
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom dplyr rename mutate filter group_by summarise
#' @keywords internal
#' @export add_period_plot
add_period_plot <- function(db_plot, ...) {

  # ---- initial part of procedure ----

  hrvpotbio <- hrvpotvem <- hrvpotdve <- NULL
  dmgtotbio <- dmgindbio <- dmgdirbio <- dmgwetbio <- dmgdrybio <- dmgsolbio <- NULL
  dmgtot <- dmgind <- dmgdir <- dmgwet <- dmgdry <- dmgsol <- NULL
  crop <- period <- ghg <- glg <- NULL

  # set optional arguments
  opt_param <- c("period_start", "period_end")
  period_start <- period_end <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))


  # ---- main part of procedure ----

  if (is.null(period_start)) period_start <- min(db_plot$year)
  if (is.null(period_end)) period_end <- max(db_plot$year)

  db_plot <- db_plot %>%
    rename(period = year)

  # set stresses (bio)
  db_tmp <- db_plot %>%
    mutate(
      dmgtotbio = hrvpotbio * dmgtot / 100,
      dmgindbio = hrvpotbio * dmgind / 100,
      dmgdirbio = hrvpotbio * dmgdir / 100,
      dmgwetbio = hrvpotbio * dmgwet / 100,
      dmgdrybio = hrvpotbio * dmgdry / 100,
      dmgsolbio = hrvpotbio * dmgsol / 100
    )

  # set average stresses for each period
  for (rec in 1:length(period_start)) {
    db_per <- db_tmp %>%
      filter(period >= period_start[rec] & period <= period_end[rec]) %>%
      group_by(crop) %>%
      summarise(
        ghg = mean(ghg),
        glg = mean(glg),
        dmgtot = sum(dmgtotbio) / sum(hrvpotbio) * 100,
        dmgind = sum(dmgindbio) / sum(hrvpotbio) * 100,
        dmgdir = sum(dmgdirbio) / sum(hrvpotbio) * 100,
        dmgwet = sum(dmgwetbio) / sum(hrvpotbio) * 100,
        dmgdry = sum(dmgdrybio) / sum(hrvpotbio) * 100,
        dmgsol = sum(dmgsolbio) / sum(hrvpotbio) * 100,
        hrvpotbio = mean(hrvpotbio),
        hrvpotvem = mean(hrvpotvem),
        hrvpotdve = mean(hrvpotdve),
        .groups = "drop"
      ) %>%
      mutate(
        period = str_c(period_start[rec], "-", period_end[rec]),
      )

    db_plot <- rbind(db_plot, db_per)
  }

  # ---- return of procedure ----

  return(db_plot)
}

#' Create figure of groundwaterlevels from SWAP
#'
#' @param file_swp character string, name of swp-file.
#' @param dir_out character string, out-directory.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom fs path_file
#' @importFrom lubridate as_date day year
#' @importFrom dplyr %>% filter mutate
#' @importFrom controlR dayyear create_label get_my_theme
#' @importFrom SWAPtools get_value_SWAP read_csv_SWAP get_gt
#' @importFrom ggplot2 ggplot aes aes_string geom_line geom_hline scale_colour_manual scale_x_continuous scale_y_continuous labs ggsave
#' @importFrom fs path_file
#' @export analyse_gwl
analyse_gwl <- function(file_swp, dir_out, ...) {

  # ---- initial part of procedure ----

  datetime <- NULL

  first_day_decade_365 <- c(1, 11, 21, 32, 42, 52, 60, 70, 80, 91, 101, 111, 121, 131, 141, 152, 162, 172, 182, 192, 202, 213, 223, 233, 244, 254, 264, 274, 284, 294, 305, 315, 325, 335, 345, 355)

  # set optional arguments
  opt_param <- c("year_start", "year_end", "width", "height", "variable_swap", "quiet")
  year_start <- year_end <- width <- height <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(width)) width <- 10
  if (is.null(height)) height <- 5
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE

  # ---- main part of procedure ----

  # load settings simulation
  OUTFIL <- TSTART <- TEND <- NULL
  settings <- get_settings_SWAP(variable = c("OUTFIL", "TSTART", "TEND"), file = file_swp, variable_swap = variable_swap, quiet = quiet)
  for (name in c("OUTFIL", "TSTART", "TEND")) assign(name, settings[[name]])

  # set period to analyse
  if (is.null(year_start)) year_start <- year(TSTART)
  if (is.null(year_end)) year_end <- year(TEND)

  # extract groundwater level
  file <- str_c(path_dir(file_swp), "/", OUTFIL,"_output.csv")
  db_swp <- read_csv_SWAP(file = file, variable = "GWL" , timestamp = FALSE)

  # set date
  db_swp <- db_swp %>%
    mutate(
      date = as_date(datetime),
      year = year(datetime),
      daynr = dayyear(datetime)
    ) %>%
    filter(year >= year_start & year <= year_end)

  # set GHG and GLG
  gxg <- extract_gxg(file_swp = file_swp, data = db_swp, year_start = year_start, year_end = year_end)

  # message to screen
  if (!quiet & !any(is.na(gxg))) {
    message(str_c("\nGHG: ", formatC(x = gxg[1] / -100, format = "f", digits = 2), " [m-mv]"))
    message(str_c("GLG: ", formatC(x = gxg[2] / -100, format = "f", digits = 2), " [m-mv]"))
    message(str_c("Gt:  ", get_gt(ghg = gxg[1], glg = gxg[2])))
  }

  # settings of x-axes
  labels <- c("Jan","Feb","Mrt","Apr","Mei","Jun","Jul","Aug","Sep","Okt","Nov","Dec")
  breaks <- first_day_decade_365[seq(from=1,to=36,by=3)]
  minor_breaks <- first_day_decade_365[sort(c(seq(from=2,to=36,by=3),seq(from=3,to=36,by=3)))]

  # limits of y-axes
  min_val <- floor(x = min(db_swp$GWL, na.rm = TRUE) / 100) * 100
  max_val <- ceiling(max(c(0, db_swp$GWL), na.rm = TRUE))

  # create figure
  P <- ggplot(data = db_swp) +
    geom_line(aes_string(x = "daynr", y = "GWL", group = "year"), colour = "lightblue", alpha = 0.5) +
    geom_line(aes_string(x = "daynr", y = "GWL", group = "year"), colour = "lightblue", alpha = 0.5) +
    scale_x_continuous(breaks = breaks, minor_breaks = minor_breaks, labels = labels) +
    scale_y_continuous(limits = c(min_val, max_val)) +
    labs(x = "", y = create_label(label = "Grondwaterstand", unit = "cm")) +
    get_my_theme("figure")

  # add gxg
  if (!any(is.na(gxg))) {
    P <- P + geom_hline(aes(yintercept = gxg[1]), colour = "blue", alpha=0.5) +
      geom_hline(aes(yintercept = gxg[2]), colour = "red", alpha=0.5)
  }

  # save figure
  filename <- str_c(dir_out, "/Grondwaterstandsverloop_jaar.png")
  ggsave(filename = filename, plot = P, width = width, height = height, dpi = "retina", bg = "white")
  if (!quiet) message(str_c("\nCreate plot: ", path_file(filename)))

  # create figure
  P <- ggplot(data = db_swp) +
    geom_line(aes_string(x = "date", y = "GWL"), colour = "lightblue", alpha = 0.5) +
    scale_y_continuous(limits = c(min_val, max_val)) +
    labs(x = "", y = create_label(label = "Grondwaterstand", unit = "cm")) +
    get_my_theme("figure")

  # add gxg
  if (!any(is.na(gxg))) {
    P <- P + geom_hline(aes(yintercept = gxg[1]), colour = "blue", alpha=0.5) +
      geom_hline(aes(yintercept = gxg[2]), colour = "red", alpha=0.5)
  }

  # save figure
  filename <- str_c(dir_out, "/Grondwaterstandsverloop_periode.png")
  ggsave(filename = filename, plot = P, width = width, height = height, dpi = "retina", bg = "white")
  if (!quiet) message(str_c("\nCreate plot: ", path_file(filename)))
}

#' Create figure of harvest and yield gap from SWAP
#'
#' @param file_ind character string, name of (SWAP)file (potential growing season).
#' @param file_dir character string, name of (SWAP)file (actual growing season).
#' @param dir_out character string, out-directory.
#' @param ... further arguments passed to or from other methods
#' @importFrom stringr str_c
#' @importFrom readr read_rds write_csv
#' @importFrom fs path_package path_file
#' @importFrom dplyr %>% select rename mutate mutate_at
#' @importFrom controlR create_label get_my_theme
#' @importFrom SWAPtools get_value_SWAP
#' @importFrom lubridate day month year
#' @importFrom ggplot2 ggplot aes_string geom_bar geom_hline scale_fill_manual labs theme element_text ggsave
#' @export analyse_harvest
analyse_harvest <- function(file_ind, file_dir, dir_out, ...) {

  # ---- initial part of procedure ----

  hrvpotbio <- hrvpotdve <- hrvpotvem <- NULL
  dmgtot <- dmgind <- dmgdir <- dmgdry <- dmgwet <- dmgsol <- NULL
  dmgtotbio <- hrvactbio <- NULL
  crop <- period <- value <- ghg <- glg <- NULL

  # set optional arguments
  opt_param <- c("year_start", "year_end", "width", "height", "settings_wwl", "variable_wwl", "variable_swap", "quiet")
  year_start <- year_end <- width <- height <- settings_wwl <- variable_wwl <- variable_swap <- quiet <- NULL

  # load additional arguments
  param <- list(...)
  for (name in names(param) ) assign(name, param[[name]])

  # check unused arguments
  unused_param <- setdiff(names(param), opt_param)
  if (length(unused_param)) stop("unused parameter: ", str_c(unused_param, collapse = ', '))

  # check used arguments
  if (is.null(width)) width <- 10
  if (is.null(height)) height <- 5
  if (is.null(settings_wwl)) settings_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_settings.rds"))
  if (is.null(variable_wwl)) variable_wwl <- read_rds(file = str_c(path_package(package = "WWLanalyse"), "/rds/wwl_variables.rds"))
  if (is.null(variable_swap)) variable_swap <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))
  if (is.null(quiet)) quiet <- TRUE

  # ---- main part of procedure ----

  # load settings simulation
  CROPFIL <- TSTART <- TEND <- NULL
  settings <- get_settings_SWAP(variable = c("TSTART", "TEND", "CROPROTATION::CROPFIL"), file = file_dir, variable_swap = variable_swap, quiet = quiet)
  for (name in c("CROPFIL", "TSTART", "TEND")) assign(name, settings[[name]])

  # set period to analyse
  if (is.null(year_start)) year_start <- year(TSTART)
  if (is.null(year_end)) year_end <- year(TEND)

  # extract crop information
  cropinfo <- settings_wwl$cropinfo
  cropfile <- cropinfo$cropfile
  cropfile <- unique(cropfile[cropfile %in% unique(CROPFIL)])

  # extract harvest
  db_plot <- collect_data_plot(
    file_ind = file_ind, file_dir = file_dir,
    year_start = year_start, year_end = year_end,
    settings_wwl = settings_wwl, variable_wwl = variable_wwl, variable_swap = variable_swap,
    quiet = quiet)

  # set actual harvest
  db_harvest <- db_plot %>%
    mutate(
      dmgtotbio = hrvpotbio * dmgtot / 100.0,
      hrvactbio = hrvpotbio - dmgtotbio
    )

  # rearrange data
  db_fig <- NULL
  column <- c("dmgtotbio", "hrvactbio")
  for (s_column in column) {
    db_tmp <- db_harvest %>%
      rename(value = all_of(s_column)) %>%
      mutate(cat = all_of(s_column)) %>%
      select(year, cat, value)
    db_fig <- rbind(db_fig, db_tmp)
  }

  # create factors
  db_fig$year <- factor(x = db_fig$year, levels = min(db_fig$year):max(db_fig$year), ordered = TRUE)
  db_fig$cat <- factor(x = db_fig$cat, levels = column, labels = c("Potentieel", "Actueel"), ordered = TRUE)

  # set unit
  unit <- unique(cropinfo$unit[cropinfo$cropfile %in% cropfile])
  if (length(unit) > 1) unit <- str_c(unit, collapse = " '|' ")

  # create figure
  P <- ggplot(data = db_fig) +
    geom_bar(aes_string(x = "year", y = "value", fill = "cat"), stat = "identity", alpha = 0.6) +
    scale_fill_manual(name = create_label(label = "Opbrengst"), values = c("darkgreen", "green")) +
    labs(x = "", y = create_label(label = "Gewasopbrengst", unit = unit)) +
    get_my_theme("figure") +
    theme(axis.text.x = element_text(angle = 270, vjust = 0.1))

  # save figure
  filename <- str_c(dir_out, "/Gewasopbrengst.png")
  ggsave(filename = filename, plot = P, width = width, height = height, dpi = "retina", bg = "white")
  if (!quiet) message(str_c("\nCreate plot: ", path_file(filename)))

  # rearrange data
  db_fig <- NULL
  column <- c("dmgind", "dmgdry", "dmgwet", "dmgsol")
  for (s_column in column) {
    db_tmp <- db_plot %>%
      rename(value = all_of(s_column)) %>%
      mutate(cat = all_of(s_column)) %>%
      select(year, cat, value)
    db_fig <- rbind(db_fig, db_tmp)
  }

  # add average stress
  db_plot <- add_period_plot(db_plot = db_plot, period_start = year_start, period_end = year_end)
  rec <- match(x = str_c(year_start, "-", year_end), table = db_plot$period)

  # message to screen
  if (!quiet) {
    message(str_c("\nTotaal:        ", formatC(x = db_plot$dmgtot[rec], format = "f", digits = 2), " [%]"))
    message(str_c("\n - Indirect:   ", formatC(x = db_plot$dmgind[rec], format = "f", digits = 2), " [%]"))
    message(str_c(" - Direct:     ", formatC(x = db_plot$dmgdir[rec], format = "f", digits = 2), " [%]"))
    message(str_c("\n   - Droogte:  ", formatC(x = db_plot$dmgdry[rec], format = "f", digits = 2), " [%]"))
    message(str_c("   - Zuurstof: ", formatC(x = db_plot$dmgwet[rec], format = "f", digits = 2), " [%]"))
    message(str_c("   - Zout:     ", formatC(x = db_plot$dmgsol[rec], format = "f", digits = 2), " [%]"))
  }

  # create factors
  db_fig$year <- factor(x = db_fig$year, levels = min(db_fig$year):max(db_fig$year), ordered = TRUE)
  db_fig$cat <- factor(x = db_fig$cat, levels = column, labels = c("indirect", "droogte", "zuurstof", "zout"), ordered = TRUE)

  # create figure
  P <- ggplot(data = db_fig) +
    geom_bar(aes_string(x = "year", y = "value", fill = "cat"), stat = "identity", alpha = 0.6) +
    geom_hline(yintercept = db_plot$dmgtot[rec], colour = "grey65", linetype = 2, size = 1.2) +
    scale_fill_manual(name = create_label(label = "Derving"), values = c("darkorange4", "red", "blue", "orange")) +
    labs(x = "", y = create_label(label = "Opbrengstderving", unit = "%")) +
    get_my_theme("figure") +
    theme(axis.text.x = element_text(angle = 270, vjust = 0.1))

  # save figure
  filename <- str_c(dir_out, "/Opbrengstderving.png")
  ggsave(filename = filename, plot = P, width = width, height = height, dpi = "retina", bg = "white")
  if (!quiet) message(str_c("\nCreate plot: ", path_file(filename)))

  # write results
  db_plot <- db_plot %>%
    mutate_at(c("ghg", "glg", "hrvpotbio", "hrvpotvem", "hrvpotdve"), round, digits = 0) %>%
    mutate_at(c("dmgtot", "dmgind", "dmgdir", "dmgwet", "dmgdry","dmgsol"), round, digits = 1) %>%
    select(period, crop, ghg, glg, hrvpotbio, hrvpotvem, hrvpotdve, dmgtot, dmgind, dmgdir, dmgwet, dmgdry, dmgsol)

  file_csv <- str_c(dir_out, "/Opbrengstderving.csv")
  write_csv(x = db_plot, file = file_csv, progress = FALSE, quote = "none")
}
