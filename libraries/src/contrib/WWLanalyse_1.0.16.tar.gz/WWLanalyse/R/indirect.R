#' Create simulation with potential growth season
#'
#' @param file_swp character string, name of swp-file
#' @importFrom fs path_dir file_copy
#' @importFrom readr read_lines write_lines
#' @importFrom controlR get_line
#' @importFrom SWAPtools get_value_SWAP
#' @keywords internal
#' @export create_indirect
create_indirect <- function(file_swp) {

  # ---- main part of procedure ----

  # set run-directory
  dir_run <- path_dir(file_swp)

  # load swp-file
  text <- read_lines(file = file_swp, lazy = FALSE)

  # adjust drainage settings
  SWDRA <- get_value_SWAP(file = file_swp, variable = "SWDRA")
  if (SWDRA != 0) {
    lns <- get_line(text = text, item = "SWDRA")
    text[lns] <- "SWDRA = 0"
  }

  # adjust bottom boundary condition
  lns <- get_line(text = text, item = "SWBBCFILE")
  text[lns] <- "  SWBBCFILE = 1"
  lns <- get_line(text = text, item = "BBCFIL")
  text[lns] <- "  BBCFIL = 'swap'"

  # write swp-file
  write_lines(x = text, file = file_swp)

  # copy bbc-file
  path <- system.file("extdata/swap.bbc", package = "WWLanalyse")
  new_path <- str_c(dir_run,"/swap.bbc")
  file_copy(path = path, new_path = new_path, overwrite = TRUE)

  # adjust cropfile
  CROPFIL  <- get_value_SWAP(file = file_swp, variable = "CROPROTATION::CROPFIL")
  CROPTYPE <- get_value_SWAP(file = file_swp, variable = "CROPROTATION::CROPTYPE")
  CROPFIL  <- unique(CROPFIL[CROPTYPE %in% 1:2])
  for (s_CROPFIL in CROPFIL) {
    FILCRP <- str_c(dir_run, "/", s_CROPFIL, ".crp")
    SWGERM <- get_value_SWAP(file = FILCRP, variable = "SWGERM")
    if (SWGERM == 2) {
      text <- read_lines(file = FILCRP, lazy = FALSE)
      lns <- get_line(text = text, item = "SWGERM")
      text[lns] <- "  SWGERM     = 1"
      write_lines(x = text, file = FILCRP)
    }
  }
}
