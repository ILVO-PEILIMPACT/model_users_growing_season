#' Execute SWAP-WOFOST simulations based on sqlite-database
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c str_replace
#' @importFrom fs path_ext
#' @importFrom readr write_lines
#' @importFrom controlR get_record get_dir string_sequence sequence_string
#' @importFrom SWAPtools get_run_id_SQL
#' @export run_datamodel_WWL
run_datamodel_WWL <- function(ctrl) {

  # ---- initial part of procedure ----

  # set directories
  dir_run <- get_dir(file = ctrl, item = "DIRRUN", create = FALSE)

  # set SWAP program and template
  command <- get_record(file = ctrl, item = "PRGSWP")
  file_swp <- get_record(file = ctrl, item = "FILSWP")
  file_dra <- get_record(file = ctrl, item = "FILDRA", item_exists = FALSE)
  dir_met <- get_record(file = ctrl, item = "DIRMET")
  dir_ini <- get_record(file = ctrl, item = "DIRINI", item_exists = FALSE)
  dir_crp <- get_record(file = ctrl, item = "DIRCRP")

  # set type of meteodata
  opt_meteo <- get_record(file = ctrl, item = "METEO", opt = c("STATION", "RADAR"), item_exists = FALSE)
  if (is.null(opt_meteo)) opt_meteo <- "STATION"

  # set database
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # check split database
  split <- FALSE
  text <- get_record(file = ctrl, item = "SPLIT", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) split <- ifelse(text == "Yes", TRUE, FALSE)
  n_split <- ifelse(split, get_record(file = ctrl, item = "NSPLIT"), 1)

  # set run_id
  run_id <- get_record(file = ctrl, item = "RUNID")

  # processes
  pre_process <- get_record(file = ctrl, item = "CREATE", opt = c("Yes", "No"), item_exists = FALSE)
  main_process <- get_record(file = ctrl, item = "RUN", opt = c("Yes", "No"), item_exists = FALSE)


  # ---- main part of procedure ----

  # set alternative file_sql
  file_tmp <- file_sql
  if (split) {
    file_ext <- path_ext(file_sql)
    file_tmp <- str_replace(string = file_sql, pattern = str_c(".", file_ext), replacement = str_c("_\\{\\{SPLIT\\}\\}.", file_ext))
  }

  check <- FALSE
  if (run_id != "ALL") {
    check <- TRUE
    run_id <- string_sequence(string = run_id)
  }

  # loop over number of databases to create
  for (i_split in 1:n_split) {

    # set filename database
    file_out <- str_replace(string = file_tmp, pattern = "\\{\\{SPLIT\\}\\}", formatC(x = i_split, format = "d", width = 2, flag = "0"))

    done <- FALSE
    if (!check) {
      s_run_id <- "ALL"
    } else {
      all_run_id <- get_run_id_SQL(file_sql = file_out)
      s_run_id <- sequence_string(sequence = all_run_id[all_run_id %in% run_id])
      if (is.na(s_run_id)) done <- TRUE
    }

    if (!done) {

      # create new controlfile
      text <- c(
        "# Controlfile WWL-regionaal",
        "# Wageningen Environmental Research",
        "#________________________________________________",
        "#",
        "",
        "# Database",
        "#------------------------------------------------",
        "",
        str_c("FILSQL                              ", file_out),
        str_c("RUNID                               ", s_run_id),
        "",
        "# Ploteigenschappen",
        "#------------------------------------------------",
        "",
        str_c("METEO                                ", opt_meteo),
        "",
        "# SWAP instellingen",
        "#------------------------------------------------",
        "",
        str_c("PRGSWP                              ", command),
        "",
        str_c("FILSWP                              ", file_swp),
        if (!is.null(file_dra)) str_c("FILDRA                              ", file_dra),
        "",
        str_c("DIRCRP                              ", dir_crp),
        if (!is.null(dir_ini)) str_c("DIRINI                              ", dir_ini),
        str_c("DIRMET                              ", dir_met),
        "",
        "# Folder-structuur",
        "#------------------------------------------------",
        "",
        str_c("DIRRUN                              ", dir_run)
      )

      # additional settings
      if (!is.null(pre_process) | !is.null(main_process)) {
        text <- c(
          text,
          "",
          "# Uitvoering",
          "#------------------------------------------------",
          "",
          if (!is.null(pre_process)) str_c("CREATE                              ", pre_process),
          if (!is.null(main_process)) str_c("RUN                                 ", main_process)
        )
      }

      # write new controlfile
      file_ext <- path_ext(ctrl)
      file_inp <- str_replace(string = ctrl, pattern = str_c(".", file_ext), replacement = str_c("_", formatC(x = i_split, format = "d", width = 2, flag = "0"), ".", file_ext))
      write_lines(x = text, file = file_inp)

      # write new commandfile
      text <- c(
        "call .\\set_Rversion.cmd",
        str_c("%Rscript% .\\Tools\\R\\WWL_uitvoeren.R ", file_inp)
      )

      file_cmd <- str_c("2_WWL_uitvoeren_", formatC(x = i_split, format = "d", width = 2, flag = "0"), ".cmd")
      write_lines(x = text, file = file_cmd)

      # execute new commandfile
      system2(command = file_cmd, wait = FALSE, invisible = FALSE)

      # wait for next set of runs
      if (i_split < n_split) Sys.sleep(5)

    }
  }
}

#' Check SWAP-WOFOST simulations based on sqlite-database
#'
#' @param ctrl character string. Name of controlfile.
#' @param type character string. Kind of check to execute, options are: 'simulation' or 'analyse'.
#' @importFrom stringr str_c str_sub str_replace
#' @importFrom fs path_file path_ext file_exists file_delete
#' @importFrom readr write_lines
#' @importFrom controlR get_record get_dir sequence_string
#' @importFrom SWAPtools get_run_id_SQL
#' @export check_datamodel_WWL
check_datamodel_WWL <- function(ctrl, type) {

  # ---- initial part of procedure ----

  # set directories
  dir_run <- get_dir(file = ctrl, item = "DIRRUN", create = FALSE)

  # set database
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # clean controls
  clean <- FALSE
  text <- get_record(file = ctrl, item = "CLEAN", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) clean <- ifelse(text == "Yes", TRUE, FALSE)

  # check split database (in case of clean)
  if (clean) {
    split <- FALSE
    text <- get_record(file = ctrl, item = "SPLIT", opt = c("Yes", "No"), item_exists = FALSE)
    if (!is.null(text)) split <- ifelse(text == "Yes", TRUE, FALSE)
    n_split <- ifelse(split, get_record(file = ctrl, item = "NSPLIT"), 1)
  }

  # ---- main part of procedure ----

  # check kind of check
  if (!type %in% c("simulation", "analyse")) stop("unknown type selected; type should be 'simulation' or 'analyse'")

  # extract run_id to check
  if (type == "simulation") {
    run_id <- get_run_id_SQL(file_sql = file_sql)
    pattern <- "^run_*.+.*.zip"
  } else {
    run_id <- filter_run_id_SQL(file_sql = file_sql, scenario_id = "direct")
    pattern <- "^ana_*.+.*.csv"
  }

  # filter successful simulations
  files <- list.files(path = dir_run, pattern = pattern, recursive = TRUE)
  succes_id <- as.numeric(str_sub(string = path_file(files), start = 5, end = 13))
  succes_id <- succes_id[succes_id %in% run_id]

  # set failed runs
  failed_id <- run_id[!run_id %in% succes_id]

  # message to screen
  message(str_c("executed: ", length(run_id)))
  message(str_c("success:  ", length(succes_id)))
  message(str_c("failed:   ", length(failed_id)))

  # write check result (in case of failure)
  if (length(failed_id) > 0) {
    text <- sequence_string(sequence = failed_id)
    file_chk <-  str_c("./failed_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".text")
    write_lines(x = text, file = file_chk)
  }

  # clean directory from multicore controlfiles
  if (clean) {

    # set list of controlfiles
    file_ext <- path_ext(ctrl)
    file_inp <- str_replace(string = ctrl, pattern = str_c(".", file_ext), replacement = str_c("_", formatC(x = 1:n_split, format = "d", width = 2, flag = "0"), ".", file_ext))

    # set list of cmd-files
    file_cmd <- c(
      str_c("2_WWL_uitvoeren_", formatC(x = 1:n_split, format = "d", width = 2, flag = "0"), ".cmd"),
      str_c("3_WWL_analyseren_", formatC(x = 1:n_split, format = "d", width = 2, flag = "0"), ".cmd")
    )

    # delete existing files
    files <- c(file_inp, file_cmd)
    files <- files[file_exists(path = files)]
    if (length(files) != 0) file_delete(path = files)
  }
}

#' Execute SWAP-WOFOST simulations based on sqlite-database
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c str_replace
#' @importFrom fs path_ext
#' @importFrom readr write_lines
#' @importFrom controlR get_record get_dir string_sequence sequence_string
#' @importFrom SWAPtools filter_run_id_SQL
#' @export ana_datamodel_WWL
ana_datamodel_WWL <- function(ctrl) {

  # ---- initial part of procedure ----

  # set directories
  dir_run <- get_dir(file = ctrl, item = "DIRRUN", create = FALSE)

  # set database
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # check split database
  split <- FALSE
  text <- get_record(file = ctrl, item = "SPLIT", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) split <- ifelse(text == "Yes", TRUE, FALSE)
  n_split <- ifelse(split, get_record(file = ctrl, item = "NSPLIT"), 1)

  # set run_id
  run_id <- get_record(file = ctrl, item = "RUNID")

  # soiltype
  type <- get_record(file = ctrl, item = "TYPE", opt = c("BODEM", "BOFEK2012", "BOFEK2020"))

  # create figure
  analyse <- get_record(file = ctrl, item = "CRTFIG", opt = c("Yes", "No"), item_exists = FALSE)

  # ---- main part of procedure ----

  # set alternative file_sql
  file_tmp <- file_sql
  if (split) {
    file_ext <- path_ext(file_sql)
    file_tmp <- str_replace(string = file_sql, pattern = str_c(".", file_ext), replacement = str_c("_\\{\\{SPLIT\\}\\}.", file_ext))
  }

  check <- FALSE
  if (run_id != "ALL") {
    check <- TRUE
    run_id <- string_sequence(string = run_id)
  }

  # loop over number of databases to create
  for (i_split in 1:n_split) {

    # set filename database
    file_out <- str_replace(string = file_tmp, pattern = "\\{\\{SPLIT\\}\\}", formatC(x = i_split, format = "d", width = 2, flag = "0"))

    done <- FALSE
    all_run_id <- filter_run_id_SQL(file_sql = file_out, scenario_id = "direct")
    if (!is.null(all_run_id)) {
      if (!check) {
        s_run_id <- sequence_string(sequence = all_run_id)
      } else {
        s_run_id <- sequence_string(sequence = all_run_id[all_run_id %in% run_id])
        if (is.na(s_run_id)) done <- TRUE
      }
    } else {
      done <- TRUE
    }

    if (!done) {

      # create new controlfile
      text <- c(
        "# Controlfile WWL-regionaal",
        "# Wageningen Environmental Research",
        "#________________________________________________",
        "#",
        "",
        "# Database",
        "#------------------------------------------------",
        "",
        str_c("FILSQL                              ", file_sql),
        str_c("RUNID                               ", s_run_id),
        "",
        "# Ploteigenschappen",
        "#------------------------------------------------",
        "",
        str_c("TYPE                                ", type),
        "",
        "# Folder-structuur",
        "#------------------------------------------------",
        "",
        str_c("DIRRUN                              ", dir_run),
        "",
        "# Analyse",
        "#------------------------------------------------",
        "",
        if (!is.null(analyse)) str_c("CRTFIG                              ", analyse)
      )

      # write new controlfile
      file_ext <- path_ext(ctrl)
      file_inp <- str_replace(string = ctrl, pattern = str_c(".", file_ext), replacement = str_c("_", formatC(x = i_split, format = "d", width = 2, flag = "0"), ".", file_ext))
      write_lines(x = text, file = file_inp)

      # write new commandfile
      text <- c(
        "call .\\set_Rversion.cmd",
        str_c("%Rscript% .\\Tools\\R\\WWL_analyseren.R ", file_inp)
      )

      file_cmd <- str_c("3_WWL_analyseren_", formatC(x = i_split, format = "d", width = 2, flag = "0"), ".cmd")
      write_lines(x = text, file = file_cmd)

      # execute new commandfile
      system2(command = file_cmd, wait = FALSE, invisible = FALSE)

      # wait for next set of runs
      if (i_split < n_split) Sys.sleep(5)

    }
  }
}
