#' Aggregate WWL results into idf-layers
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c str_replace_all str_to_upper
#' @importFrom fs path_package path_file dir_ls file_exists
#' @importFrom lubridate year
#' @importFrom readr read_rds read_csv
#' @importFrom controlR get_record get_dir
#' @importFrom tibble as_tibble add_column
#' @importFrom dplyr %>% mutate filter select rename all_of if_else
#' @importFrom ascR get_head_asc write_asc
#' @importFrom idfR get_head_idf write_idf
#' @importFrom RSQLite dbConnect dbGetQuery dbDisconnect
#' @importFrom progress progress_bar
#' @export output_datamodel_WWL
output_datamodel_WWL <- function(ctrl) {

  # ---- initial part of procedure ----

  x_crd <- y_crd <- value <- NULL
  dmgtot <- dmgind <- dmgdir <- dmgdry <- dmgwet <- dmgsol <- NULL
  hrvpotbio <- hrvpoteur <- hrvpotvem <- hrvpotdve <- NULL
  dm <- euro <- NULL

  # load settings watervision agriculture
  wwl <- read_rds(file = str_c(path_package(package = "WWLregionaal"), "/rds/wwl_settings.rds"))

  # set crop-prices
  VALUE <- get_record(file = ctrl, item = "VEM" , item_exists = FALSE)
  if (!is.null(VALUE)) wwl$euro_vem <- VALUE
  VALUE <- get_record(file = ctrl, item = "DVE" , item_exists = FALSE)
  if (!is.null(VALUE)) wwl$euro_dve <- VALUE

  for (cropname in wwl$cropinfo$cropname[!is.na(wwl$cropinfo$euro)]) {
    VALUE <- get_record(file = ctrl, item = str_to_upper(cropname), item_exists = FALSE)
    if (!is.null(VALUE)) wwl$cropinfo$euro[wwl$cropinfo$cropname == cropname] <- VALUE
  }

  # set name of sql-file
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # set directories
  dir_run <- get_dir(file = ctrl, item = "DIRRUN")
  dir_out <- get_dir(file = ctrl, item = "DIROUT")

  # set period
  tstart <- get_record(file = ctrl, item = "TSTART")
  tend <- get_record(file = ctrl, item = "TEND")

  # set layer format
  format <- "idf"
  text <- get_record(file = ctrl, item = "FORMAT", opt = c("asc", "idf"), item_exists = FALSE)
  if (!is.null(text)) format <- text

  # set output
  item <- str_to_upper(wwl$ITEMOUT)
  item_out <- rep(x = TRUE, times = length(item))
  for (rec in 1:length(item)) {
    VALUE <- get_record(file = ctrl, item = item[rec] , opt = c("Yes", "No"), item_exists = FALSE)
    if (!is.null(VALUE)) {
      if (VALUE == "No") item_out[rec] <- FALSE
    }
  }
  if (all(!item_out)) stop("No output variables selected!")
  wwl$sel_ITEMOUT <- wwl$ITEMOUT[item_out]

  # ---- main part of procedure ----

  # set crop_id for calculation of economic potential yield
  forage <- wwl$cropinfo$gewas_id[is.na(wwl$cropinfo$euro)]
  drymatter <- wwl$cropinfo$gewas_id[!is.na(wwl$cropinfo$euro)]

  message("collect results...")

  # check length period
  opt_gxg <- ifelse(year(tend) - year(tstart) + 1 >= 6, TRUE, FALSE)
  if (!opt_gxg) message("unable to determine GHG and GLG; period too short")

  # check available run_id
  file_ana <- path_file(dir_ls(path = dir_run, type = "file", regexp = "ana_*"))
  run_id <- as.numeric(str_replace_all(string = file_ana, pattern = "ana_|.csv", replacement = ""))
  if (length(run_id) == 0) stop("no results to collect")

  # extract coordinates
  if (!file_exists(path = file_sql)) stop(str_c("\nfile does not exists '", path_file(file_sql), "'"))
  conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql)
  db_run <- as_tibble(dbGetQuery(conn = conn, statement = str_c("SELECT run_id, crop_id, x_crd, y_crd FROM Runs WHERE scenario_id in ('direct')")))
  dbDisconnect(conn = conn)
  db_run <- db_run[db_run$run_id %in% run_id, ]
  if (nrow(db_run) == 0) stop("no results to collect")

  # set idf settings
  file <- str_replace(string = file_sql, pattern = path_ext(path = file_sql), replacement = format)
  if (format == "idf") head <- get_head_idf(file = file)
  if (format == "asc") head <- get_head_asc(file = file)

  average <- str_c(year(tstart), "-", year(tend))
  average_winter <- str_c(year(tstart) + 1, "-", year(tend))
  period <- c(average, year(tstart):year(tend))
  for (s_period in period) {

    # set db_plot (default nodata)
    db_plot <- db_run %>%
      mutate(
        col = ifelse(x_crd == head$xmax, head$ncol, floor((x_crd - head$xmin) / head$dx) + 1),
        row = ifelse(y_crd == head$ymin, head$nrow, floor((head$ymax - y_crd) / head$dy) + 1)
      )

    if (opt_gxg & s_period == average) {
      db_plot <- db_plot %>%
        mutate(
          ghg = head$nodata,
          glg = head$nodata
        )
    }

    db_plot <- db_plot %>%
      mutate(
        hrvpotbio = head$nodata,
        hrvpotvem = head$nodata,
        hrvpotdve = head$nodata,
        hrvpoteur = head$nodata,
        dmgtot = head$nodata,
        dmgind = head$nodata,
        dmgdir = head$nodata,
        dmgdry = head$nodata,
        dmgwet = head$nodata,
        dmgsol = head$nodata
      )

    # set read-format
    col_types <- ifelse(opt_gxg & s_period == average, "ccddddd-d-ddd", "cc--ddd-d-ddd")

    # set values
    pb <- progress_bar$new(total = nrow(db_plot), format = str_c("- period: ", s_period, "... :percent"), clear = TRUE)
    for (rec in 1:nrow(db_plot)) {

      run_id <- db_plot$run_id[rec]
      crop_id <- db_plot$crop_id[rec]

      # load data and set record of period
      db_tmp <- read_csv(file = str_c(dir_run, "/ana_", formatC(x = run_id, format = "d", width = 9, flag = 0), ".csv"), col_types = col_types, lazy = FALSE, progress = FALSE)
      if (s_period == average) {
        t_period <- ifelse(crop_id %in% c(7, 20), average_winter, average)
      } else {
        t_period <- s_period
      }
      record <- match(x = t_period, table = db_tmp$period)

      if (opt_gxg & s_period == average) {
        db_plot$ghg[rec] <- db_tmp$ghg[record]
        db_plot$glg[rec] <- db_tmp$glg[record]
      }

      db_plot$dmgind[rec] <- db_tmp$dmgind[record]
      db_plot$dmgdry[rec] <- db_tmp$dmgdry[record]
      db_plot$dmgwet[rec] <- db_tmp$dmgwet[record]
      db_plot$dmgsol[rec] <- db_tmp$dmgsol[record]

      # calculate (economic) potential yield
      db_plot$hrvpotbio[rec] <- db_tmp$hrvpotbio[record]
      if (crop_id %in% forage) {
        db_plot$hrvpotvem[rec] <- db_tmp$hrvpotvem[record]
        db_plot$hrvpotdve[rec] <- db_tmp$hrvpotdve[record]
        db_plot$hrvpoteur[rec] <- db_tmp$hrvpotvem[record] * wwl$euro_vem + db_tmp$hrvpotdve[record] * wwl$euro_dve
      }
      if (crop_id %in% drymatter) {
        dm <- wwl$cropinfo$dm[match(x = crop_id, table = wwl$cropinfo$gewas_id)]
        euro <- wwl$cropinfo$euro[match(x = crop_id, table = wwl$cropinfo$gewas_id)]
        db_plot$hrvpoteur[rec] <- db_tmp$hrvpotbio[record] / dm * euro
      }

      # set progress
      pb$tick()

      # clear memory
      remove(db_tmp)
    }

    # set total values and delete missing records
    db_plot <- db_plot %>%
      mutate(
        dmgdir = dmgdry + dmgwet + dmgsol,
        dmgtot = dmgind + dmgdir
      ) %>%
      filter(!is.na(dmgtot))

    # write rasters
    clm <- wwl$sel_ITEMOUT
    if (opt_gxg & s_period == average) clm <- c("ghg", "glg", clm)

    for (s_clm in clm) {

      # set data layer
      data <- db_plot %>%
        rename(value = all_of(s_clm)) %>%
        select(col, row, value)

      layer <- head
      layer$data <- data

      # write rasters
      if (s_clm %in% c("ghg", "glg") & s_period == average) {
        file <- str_c(dir_out, "/", s_clm, "-__.", format)
        if (format == "idf") write_idf(file = file, idf = layer)
        if (format == "asc") write_asc(file = file, asc = layer)
      }
      if (s_clm %in% wwl$sel_ITEMOUT) {
        file <- str_c(dir_out, "/", s_clm, "-__-", s_period, ".", format)
        if (format == "idf") write_idf(file = file, idf = layer)
        if (format == "asc") write_asc(file = file, asc = layer)
      }
    }

    message(str_c("- period: ", s_period, "... : done"))

    # clear memory
    remove(db_plot)
    gc(verbose = FALSE)

  }

}
