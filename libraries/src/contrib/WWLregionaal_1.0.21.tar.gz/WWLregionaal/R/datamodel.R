#' Create zonal by extent
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c
#' @importFrom controlR get_record
#' @importFrom tibble as_tibble
#' @importFrom dplyr %>% mutate
#' @keywords internal
create_zonal_by_extent <- function(ctrl) {

  # ---- initial part of procedure ----

  col <- row <- x_crd <- y_crd <- NULL

  # set extent
  cellsize <- get_record(file = ctrl, item = "CELLSIZE")
  xmin <- get_record(file = ctrl, item = "XMIN")
  xmax <- get_record(file = ctrl, item = "XMAX")
  ymin <- get_record(file = ctrl, item = "YMIN")
  ymax <- get_record(file = ctrl, item = "YMAX")


  # ---- main part of procedure ----

# set col and row
  cols <- seq(from = 1, to = (xmax - xmin) / cellsize, by = 1)
  rows <- seq(from = 1, to = (ymax - ymin) / cellsize, by = 1)

  # create data with every combination
  db <- as_tibble(expand.grid(col = cols, row = rows)) %>%
    mutate(
      x_crd = xmin + (0.5 * cellsize) + (col - 1) * cellsize,
      y_crd = ymax - (0.5 * cellsize) - (row - 1) * cellsize
    ) %>%
    select(x_crd, y_crd)

  # ---- return of procedure ----

  return(db)
}

#' Create zonal by extent
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c
#' @importFrom fs path_file path_ext
#' @importFrom controlR get_record
#' @importFrom idfR read_idf
#' @importFrom ascR read_asc
#' @importFrom dplyr %>% mutate filter select
#' @keywords internal
create_zonal_by_layer <- function(ctrl) {

  # ---- initial part of procedure ----

  col <- row <- x_crd <- y_crd <- value <- NULL

  # set layers zonal
  zonal <- get_record(file = ctrl, item = "ZONAL")

  # set extent
  ext <- tolower(path_ext(path = zonal))
  if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = zonal), "'"))


  # ---- main part of procedure ----

  # load zonal setup
  if (ext == "idf") lyr <- read_idf(file = zonal)
  if (ext == "asc") lyr <- read_asc(file = zonal)
  db <- lyr$data %>%
    filter(value != lyr$nodata) %>%
    mutate(
      x_crd = lyr$xmin + (0.5 * lyr$dx) + (col - 1) * lyr$dx,
      y_crd = lyr$ymax - (0.5 * lyr$dy) - (row - 1) * lyr$dy
    ) %>%
    select(x_crd, y_crd)

  # ---- return of procedure ----

  return(db)
}

#' Add mean surface level
#'
#' @param ctrl character string. Name of controlfile.
#' @param db dataframe with xy-coords.
#' @importFrom ascR get_data_asc
#' @importFrom idfR get_data_idf
#' @importFrom dplyr %>% mutate
#' @keywords internal
add_msl <- function(ctrl, db) {

  # ---- initial part of procedure ----

  x_crd <- y_crd <- msl <- NULL

  maaiveld <- get_record(file = ctrl, item = "MAAIVELD")

  # ---- main part of procedure ----

  # extract surface level (NAP)
  ext <- tolower(path_ext(path = maaiveld))
  if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = maaiveld), "'"))
  if (ext == "idf") db <- db %>% mutate(msl = get_data_idf(file = maaiveld, x_crd = x_crd, y_crd = y_crd))
  if (ext == "asc") db <- db %>% mutate(msl = get_data_asc(file = maaiveld, x_crd = x_crd, y_crd = y_crd))

  # ---- return of procedure ----

  return(db)
}

#' Add unique rain plots
#'
#' @param ctrl character string. Name of controlfile.
#' @param db dataframe with xy-coords.
#' @importFrom fs path_ext
#' @importFrom stringr str_replace
#' @importFrom lubridate year month day
#' @importFrom controlR get_record
#' @importFrom ascR get_data_asc get_col_asc get_row_asc
#' @importFrom idfR get_data_idf get_col_idf get_row_idf
#' @importFrom dplyr %>% mutate select arrange left_join
#' @keywords internal
add_rain_id <- function(ctrl, db) {

  # ---- initial part of procedure ----

  x_crd <- y_crd <- rain_id <- col_tmp <- row_tmp <- record <- . <- NULL

  # check if rainfall data is specified
  opt_meteo <- get_record(file = ctrl, item = "METEO", opt = c("STATION", "RADAR"), item_exists = FALSE)
  if (is.null(opt_meteo)) opt_meteo <- "STATION"

  if (opt_meteo == "RADAR") {
    tstart <- get_record(file = ctrl, item = "TSTART")
    file_rain <- get_record(file = ctrl, item = "RAIN")
  }

  # ---- main part of procedure ----

  # set set rain_id
  if (opt_meteo != "RADAR") {

    db <- db %>% mutate(rain_id = as.integer(1))

  } else {

    YYYYMMDD <- str_c(year(tstart), formatC(x = month(tstart), format = "d", width = 2, flag = "0"), formatC(x = day(tstart), format = "d", width = 2, flag = "0"))

    # check extent
    ext <- tolower(path_ext(file_rain))

    # set column and row numbers
    file <- str_replace(string = file_rain, pattern = "\\{\\{YYYYMMDD\\}\\}", replacement = YYYYMMDD)
    if (ext == "asc") {
      db <- db %>%
        mutate(
          record = 1:nrow(.),
          col_tmp = get_col_asc(file = file, x_crd = x_crd),
          row_tmp = get_row_asc(file = file, y_crd = y_crd),
        )
    }
    if (ext == "idf") {
      db <- db %>%
        mutate(
          record = 1:nrow(.),
          col_tmp = get_col_idf(file = file, x_crd = x_crd),
          row_tmp = get_row_idf(file = file, y_crd = y_crd),
        )
    }

    # set rain_id
    db_rain <- db %>%
      select(col_tmp, row_tmp) %>%
      unique() %>%
      mutate(rain_id = 1:nrow(.))

    # combine data
    db <- left_join(x = db , y = db_rain, by = c("col_tmp", "row_tmp")) %>%
      arrange(record) %>%
      select(-record, -col_tmp, -row_tmp)
  }

  # ---- return of procedure ----

  return(db)
}

#' Create table with runs
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c
#' @importFrom fs path_package path_file path_ext
#' @importFrom readr read_csv
#' @importFrom controlR get_record is_numeric
#' @importFrom dplyr %>% mutate filter select if_else
#' @importFrom idfR read_idf
#' @importFrom ascR read_asc
#' @keywords internal
create_table_runs <- function(ctrl) {

  # ---- initial part of procedure ----

  x_crd <- y_crd <- msl <- NULL
  run_id <- crop_id <- soil_id <- prof_id <- meteo_id <- rain_id <- irrigation_id <- solute_id <- scenario_id <- SWBOTB <- NULL

  # set extent modus
  zonal <- get_record(file = ctrl, item = "ZONAL", item_exists = FALSE)
  modus <- ifelse(is.null(zonal), "extent", "layer")

  # set layers for crop and soil
  gewas <- get_record(file = ctrl, item = "GEWAS")
  gewas_wwl <- get_record(file = ctrl, item = "GEWAS_WWL", item_exists = FALSE)
  bodem <- get_record(file = ctrl, item = "BODEM")
  bodem_wwl <- get_record(file = ctrl, item = "BODEM_WWL", item_exists = FALSE)

  # set meteorology
  opt_meteo <- get_record(file = ctrl, item = "METEO", opt = c("STATION", "RADAR"), item_exists = FALSE)
  if (is.null(opt_meteo)) opt_meteo <- "STATION"
  station <- get_record(file = ctrl, item = "STATION")

  irrigatie <- get_record(file = ctrl, item = "IRRIGATIE")
  zout <- get_record(file = ctrl, item = "ZOUT", item_exists = FALSE)
  if (is.null(zout)) zout <- 0

  # set type bottom boundary
  onderrand <- get_record(file = ctrl, item = "ONDERRAND", opt = c("GRONDWATERSTAND", "STIJGHOOGTE", "DRUKHOOGTE"))

  # indirect effects
  indirect <- TRUE
  text <- get_record(file = ctrl, item = "INDIRECT", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) indirect <- ifelse(text == "Yes", TRUE, FALSE)

  # ---- main part of procedure ----

  # set zonal setup
  if (modus == "extent") db <- create_zonal_by_extent(ctrl = ctrl)
  if (modus == "layer") db <- create_zonal_by_layer(ctrl = ctrl)
  db <- add_msl(ctrl = ctrl, db = db)

  # set crop_id
  if (is_numeric(text = gewas)) {
    db <- db %>% mutate(crop_id = gewas)
  } else {
    ext <- tolower(path_ext(path = gewas))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = gewas), "'"))
    if (ext == "idf") db <- db %>% mutate(crop_id = get_data_idf(file = gewas, x_crd = x_crd, y_crd = y_crd))
    if (ext == "asc") db <- db %>% mutate(crop_id = get_data_asc(file = gewas, x_crd = x_crd, y_crd = y_crd))
  }

  if (!is.null(gewas_wwl)) {
    db_tmp <- read_csv(file = gewas_wwl, lazy = FALSE, show_col_types = FALSE)
    uni_id <- sort(unique(db$crop_id))
    idx <- uni_id %in% db_tmp$CODE
    if (!all(idx)) warning(str_c("unknown crop id '", uni_id[!idx], "'\n"))
    db_tmp <- db_tmp[db_tmp$WWL != -99, c("CODE", "WWL")]
    db <- db %>% mutate(crop_id = db_tmp$WWL[match(x = db$crop_id, table = db_tmp$CODE)])
  }
  db <- db %>%
    filter(!is.na(crop_id) & crop_id > 0) %>%
    mutate(prof_id = if_else(crop_id <= 5, "G", "A"))
  if (nrow(db) == 0) stop("no records left after processing crop data!")

  # set soil_id
  if (is_numeric(text = bodem)) {
    db <- db %>% mutate(soil_id = bodem)
  } else {
    ext <- tolower(path_ext(path = bodem))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = bodem), "'"))
    if (ext == "idf") db <- db %>% mutate(soil_id = get_data_idf(file = bodem, x_crd = x_crd, y_crd = y_crd))
    if (ext == "asc") db <- db %>% mutate(soil_id = get_data_asc(file = bodem, x_crd = x_crd, y_crd = y_crd))
  }

  if (!is.null(bodem_wwl)) {
    db_tmp <- read_csv(file = bodem_wwl, lazy = FALSE, show_col_types = FALSE)
    uni_id <- sort(unique(db$soil_id))
    idx <- uni_id %in% db_tmp$CODE
    if (!all(idx)) warning(str_c("unknown soil id '", uni_id[!idx], "'\n"))
    db_tmp <- db_tmp[db_tmp$WWL != -99, c("CODE", "WWL")]
    db <- db %>% mutate(soil_id = db_tmp$WWL[match(x = db$soil_id, table = db_tmp$CODE)])
  }
  db <- db %>%
    filter(!is.na(soil_id) & soil_id > 0)
  if (nrow(db) == 0) stop("no records left after processing soil data!")

  # set meteo_id
  if (is_numeric(text = station)) {
    db <- db %>% mutate(meteo_id = station)
  } else {
    ext <- tolower(path_ext(path = station))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = station), "'"))
    if (ext == "idf") db <- db %>% mutate(meteo_id = get_data_idf(file = station, x_crd = x_crd, y_crd = y_crd))
    if (ext == "asc") db <- db %>% mutate(meteo_id = get_data_asc(file = station, x_crd = x_crd, y_crd = y_crd))
    db <- db %>% filter(!is.na(meteo_id) & meteo_id > 0)
    if (nrow(db) == 0) stop("no records left after processing meteo data!")
  }

  # set rain_id
  db <- add_rain_id(ctrl = ctrl, db = db)

  # set irrigation_id
  if (is_numeric(text = irrigatie)) {
    db <- db %>% mutate(irrigation_id = irrigatie)
  } else {
    ext <- tolower(path_ext(path = irrigatie))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = irrigatie), "'"))
    if (ext == "idf") db <- db %>% mutate(irrigation_id = get_data_idf(file = irrigatie, x_crd = x_crd, y_crd = y_crd))
    if (ext == "asc") db <- db %>% mutate(irrigation_id = get_data_asc(file = irrigatie, x_crd = x_crd, y_crd = y_crd))
    db <- db %>% filter(!is.na(irrigation_id))
    if (nrow(db) == 0) stop("no records left after processing irrigation data!")
  }

  # set solute_id
  if (is_numeric(text = zout)) {
    db <- db %>% mutate(solute_id = zout)
  } else {
    ext <- tolower(path_ext(path = zout))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = zout), "'"))
    if (ext == "idf") db <- db %>% mutate(solute_id = get_data_idf(file = zout, x_crd = x_crd, y_crd = y_crd))
    if (ext == "asc") db <- db %>% mutate(solute_id = get_data_asc(file = zout, x_crd = x_crd, y_crd = y_crd))
    db <- db %>% filter(!is.na(solute_id))
    if (nrow(db) == 0) stop("no records left after processing solute data!")
  }

  # set bottom boundary
  db <- db %>%
    mutate(SWBOTB = ifelse(onderrand == "GRONDWATERSTAND", 1, ifelse(onderrand == "STIJGHOOGTE", 3, 5)))

  # set run_id, rain_id and scenario
  db_run <- db %>%
    mutate(
      run_id = 1:nrow(db),
      scenario_id = "direct"
    ) %>%
    select(run_id, soil_id, prof_id, meteo_id, rain_id, crop_id, irrigation_id, solute_id, scenario_id, SWBOTB, x_crd, y_crd, msl)

  # create unique combinations (indirect)
  if (indirect) {
    max_id <- nrow(db_run)
    db_ind <- db_run %>%
      select(crop_id, soil_id, prof_id, meteo_id, rain_id) %>%
      unique()
    db_ind <- db_ind %>%
      mutate(
        run_id = max_id + 1:nrow(db_ind),
        x_crd = NA_real_,
        y_crd = NA_real_,
        msl = NA_real_,
        irrigation_id = 0,
        solute_id = 0,
        SWBOTB = 5,
        scenario_id = "indirect"
      )

    # combine, add run_id and prepare for output
    db_run <- rbind(db_run, db_ind) %>%
      select(run_id, soil_id, prof_id, meteo_id, rain_id, crop_id, irrigation_id, solute_id, scenario_id, SWBOTB, x_crd, y_crd, msl)
  }

  message("- load zonal... done")

  # ---- return of procedure ----

  return(db_run)
}

#' Create table meteorology
#'
#' @param ctrl character string. Name of controlfile.
#' @param conn connection of db-sqlite.
#' @param db_run tibble data frame. List of run_id and coordinates.
#' @importFrom stringr str_c str_replace str_replace_all str_split
#' @importFrom fs path_file path_dir path_ext
#' @importFrom controlR get_record
#' @importFrom lubridate as_date year month day
#' @importFrom idfR get_data_idf
#' @importFrom ascR get_data_asc
#' @importFrom RSQLite dbWriteTable dbExecute
#' @importFrom tibble tibble
#' @importFrom dplyr %>% mutate rename select if_else
#' @importFrom KNMItools get_station_meteo_KNMI
#' @importFrom progress progress_bar
#' @keywords internal
create_table_meteo <- function(ctrl, conn, db_run) {

  # ---- initial part of procedure ----

  run_id <- meteo_id <- rain_id <- scenario_id <- x_crd <- y_crd <- METFIL <- NULL

  # set period
  tstart <- get_record(file = ctrl, item = "TSTART")
  tend <- get_record(file = ctrl, item = "TEND")

  opt_meteo <- get_record(file = ctrl, item = "METEO", opt = c("STATION", "RADAR"), item_exists = FALSE)
  if (is.null(opt_meteo)) opt_meteo <- "STATION"

  # set station
  station <- get_record(file = ctrl, item = "STATION")

  # load settings KNMI
  knmi_station <- get_station_meteo_KNMI()

  # load rainfall from radar (optional)
  file_wet <- NULL
  if (opt_meteo == "RADAR") {
    file_rain <- get_record(file = ctrl, item = "RAIN")
    file_wet <- get_record(file = ctrl, item = "WET", item_exists = FALSE)
  }

  # ---- main part of procedure ----

  # set duration of rainfall
  SWRAIN <- 2
  if (opt_meteo == "RADAR") SWRAIN <- ifelse(is.null(file_wet), 0, 2)

  # set data meteorology
  meteo_id <- sort(unique(db_run$meteo_id))
  idx <- match(x = meteo_id, table = knmi_station$STN)
  if (!all(!is.na(idx))) stop(str_c("unable to add meteorology\n",str_c("unable to find station: '", meteo_id[is.na(idx)], "'", collapse = "\n")))
  db_met <- tibble(meteo_id = meteo_id, METFIL = str_c(meteo_id, ".met"), SWRAIN = SWRAIN, ATMOFIL = "atmospheric", LAT = knmi_station$LAT[idx], ALT = knmi_station$ALT[idx], ALTW = 10.0, TSTART = tstart, TEND = tend)
  if (opt_meteo == "RADAR") db_met <- db_met %>% select(-METFIL)

  # upload settings meteorology
  dbWriteTable(conn = conn, name = "Meteo", value = db_met)
  index <- names(db_met)[regexpr(pattern = "_id", text = names(db_met)) > 0]
  statement <- str_c("CREATE INDEX swap_idx_Meteo ON Meteo (", str_c(index, collapse = ", "), ")")
  check <- dbExecute(conn = conn, statement = statement)

  # set data station
  if (opt_meteo == "RADAR") {

    # set data station
    db_station <- db_run %>%
      select(meteo_id, rain_id) %>%
      unique() %>%
      mutate(METFIL = str_c(meteo_id, "_", rain_id, ".met"))

    # upload settings meteorology
    dbWriteTable(conn = conn, name = "Station", value = db_station)
    index <- names(db_station)[regexpr(pattern = "_id", text = names(db_station)) > 0]
    statement <- str_c("CREATE INDEX swap_idx_Station ON Station (", str_c(index, collapse = ", "), ")")
    check <- dbExecute(conn = conn, statement = statement)

  }

  message("- meteorology... done")

}

#' Create table rain
#'
#' @param ctrl character string. Name of controlfile.
#' @param conn connection of db-sqlite.
#' @param db_run tibble data frame. List of run_id and coordinates.
#' @param db_rain tibble data frame. List of all rain_id and coordinates.
#' @importFrom stringr str_c str_replace str_replace_all str_split
#' @importFrom fs path_file path_dir path_ext
#' @importFrom controlR get_record
#' @importFrom lubridate year month day
#' @importFrom idfR get_data_idf
#' @importFrom ascR get_data_asc
#' @importFrom RSQLite dbWriteTable dbExecute
#' @importFrom dplyr %>% mutate filter group_by summarise select
#' @importFrom progress progress_bar
#' @keywords internal
create_table_rain <- function(ctrl, conn, db_run, db_rain) {

  # ---- initial part of procedure ----

  rain_id <- scenario_id <- x_crd <- y_crd <- NULL

  # set period
  tstart <- get_record(file = ctrl, item = "TSTART")
  tend <- get_record(file = ctrl, item = "TEND")

  # load rainfall from radar (optional)
  file_rain <- get_record(file = ctrl, item = "RAIN")
  file_wet <- get_record(file = ctrl, item = "WET", item_exists = FALSE)

  # ---- main part of procedure ----

  date <- seq.Date(from = tstart, to = tend, by = 1)
  YYYYMMDD <- str_c(year(date), formatC(x = month(date), format = "d", width = 2, flag = "0"), formatC(x = day(date), format = "d", width = 2, flag = "0"))

  # create empty database
  all_rain_id <- sort(unique(db_run$rain_id))
  db_empty <- db_rain %>%
    filter(rain_id %in% all_rain_id) %>%
    select(rain_id, x_crd, y_crd)

  # check extent
  ext_rain <- tolower(path_ext(file_rain))
  if (!is.null(file_wet)) ext_wet <- tolower(path_ext(file_wet))

  # loop over date
  rec <- 1:length(date)
  pb <- progress_bar$new(total = length(rec), format = "- rainfall... :percent", clear = TRUE)
  for (s_rec in rec) {

    db_tmp <- db_empty %>%
      mutate(DATE = date[s_rec])

    # extract rainfall (RH)
    file <- str_replace(string = file_rain, pattern = "\\{\\{YYYYMMDD\\}\\}", replacement = YYYYMMDD[s_rec])
    if (ext_rain == "idf") db_tmp <- db_tmp %>% mutate(RAIN = get_data_idf(file = file, x_crd = x_crd, y_crd = y_crd))
    if (ext_rain == "asc") db_tmp <- db_tmp %>% mutate(RAIN = get_data_asc(file = file, x_crd = x_crd, y_crd = y_crd))

    # extract rainfall duration (DR)
    if (!is.null(file_wet)) {
      file <- str_replace(string = file_wet, pattern = "\\{\\{YYYYMMDD\\}\\}", replacement = YYYYMMDD[s_rec])
      if (ext_wet == "idf") db_tmp <- db_tmp %>% mutate(WET = get_data_idf(file = file, x_crd = x_crd, y_crd = y_crd))
      if (ext_wet == "asc") db_tmp <- db_tmp %>% mutate(WET = get_data_asc(file = file, x_crd = x_crd, y_crd = y_crd))
    }

    # select columns
    db_tmp <- db_tmp %>% select(-x_crd, -y_crd)

    # upload boundary condition (each date)
    append <- ifelse(s_rec == 1, FALSE, TRUE)
    dbWriteTable(conn = conn, name = "Rain", value = db_tmp, overwrite = !append, append = append)

    # set progress
    pb$tick()

  }

  index <- names(db_tmp)[regexpr(pattern = "_id", text = names(db_tmp)) > 0]
  statement <- str_c("CREATE INDEX swap_idx_Rain ON Rain (", str_c(index, collapse = ", "), ")")
  check <- dbExecute(conn = conn, statement = statement)

  message("- rainfall... done")
}

#' Create table with croprotation
#'
#' @param ctrl character string. Name of controlfile.
#' @param conn connection of db-sqlite.
#' @param db_run tibble data frame. List of run_id and coordinates.
#' @importFrom stringr str_c
#' @importFrom fs path_package path_file
#' @importFrom readr read_rds read_csv
#' @importFrom RSQLite dbWriteTable dbExecute
#' @importFrom controlR get_record get_dir
#' @importFrom tibble tibble as_tibble add_row
#' @importFrom dplyr %>% arrange
#' @keywords internal
create_table_croprotation <- function(ctrl, conn, db_run) {

  # ---- initial part of procedure ----

  CROPSTART <- NULL
  # load settings watervision agriculture
  wwl <- read_rds(file = str_c(path_package(package = "WWLregionaal"), "/rds/wwl_settings.rds"))
  cropinfo <- wwl$cropinfo

  # set period
  tstart <- get_record(file = ctrl, item = "TSTART")
  tend <- get_record(file = ctrl, item = "TEND")

  # set directory datamodel
  dir_mdl <- get_dir(file = ctrl, item = "DIRMDL", create = FALSE, item_exists = FALSE)

  # ---- main part of procedure ----

  # set period
  yearstart <- year(tstart)
  yearend <- year(tend)

  # load croprotation
  if (is.null(dir_mdl)) {
    db_ini <- suppressMessages(read_csv(file = str_c(path_package(package = "WWLregionaal"), "/ini/gewasrotatie.ini"), lazy = FALSE))
  } else {
    db_ini <- suppressMessages(read_csv(file = str_c(dir_mdl, "/gewasrotatie.ini"), lazy = FALSE))
  }

  # set summer and winter crops
  cropstart <- as_date(str_c(yearstart, db_ini$CROPSTART, sep = "-"))
  cropend <- as_date(str_c(yearstart, db_ini$CROPEND, sep = "-"))
  db_ini$cropseason <- ifelse(cropend > cropstart, "summer", "winter")
  index <- !is.na(db_ini$CATCHSTART)
  if (!all(!index)) {
    db_ini$catchseason <- NA
    catchstart <- as_date(str_c(yearstart, db_ini$CATCHSTART[index], sep = "-"))
    catchend <- as_date(str_c(yearstart, db_ini$CROPSTART[index], sep = "-")) - 1
    db_ini$catchseason[index] <- ifelse(catchend > catchstart, "summer", "winter")
  }

  # set first and last date
  datefirst <- as_date(str_c(yearstart, "01-01", sep = "-"))
  datelast <- as_date(str_c(yearend, "12-31", sep = "-"))

  # loop over crops
  crop_id <- sort(unique(db_run$crop_id))
  for (s_crop_id in crop_id) {

    cropfile <- cropinfo$cropfile[cropinfo$gewas_id == s_crop_id]
    croptype <- cropinfo$croptype[cropinfo$gewas_id == s_crop_id]

    # set croprotation
    if (db_ini$cropseason[db_ini$crop_id == s_crop_id] == "summer") {
      year <- yearstart:yearend
      cropstart <- as_date(str_c(year, db_ini$CROPSTART[db_ini$crop_id == s_crop_id], sep = "-"))
      cropend <- as_date(str_c(year, db_ini$CROPEND[db_ini$crop_id == s_crop_id], sep = "-"))
    } else {
      year <- yearstart:(yearend - 1)
      cropstart <- as_date(str_c(year, db_ini$CROPSTART[db_ini$crop_id == s_crop_id], sep = "-"))
      cropend <- as_date(str_c(year + 1, db_ini$CROPEND[db_ini$crop_id == s_crop_id], sep = "-"))
    }
    db_tmp <- tibble(crop_id = s_crop_id, CROPSTART = cropstart, CROPEND = cropend, CROPNAME = cropfile, CROPFIL = cropfile, CROPTYPE = croptype)

    # add catch crop
    if (!is.na(db_ini$CATCHSTART[db_ini$crop_id == s_crop_id])) {

      if (db_ini$catchseason[db_ini$crop_id == s_crop_id] == "summer") {

        year <- yearstart:yearend

        cropstart <- as_date(str_c(year, db_ini$CATCHSTART[db_ini$crop_id == s_crop_id], sep = "-"))
        cropend <- as_date(str_c(year, db_ini$CROPSTART[db_ini$crop_id == s_crop_id], sep = "-")) - 1

      } else {

        year <- (yearstart - 1):yearend

        cropstart <- as_date(str_c(year, db_ini$CATCHSTART[db_ini$crop_id == s_crop_id], sep = "-"))
        cropend <- as_date(str_c(year + 1, db_ini$CROPSTART[db_ini$crop_id == s_crop_id], sep = "-")) - 1

      }

      cropstart[1] <- datefirst
      if (cropend[length(cropend)] > datelast) cropend[length(cropend)] <- datelast

      # combine croprotation
      db_tmp <- db_tmp %>%
        add_row(crop_id = s_crop_id, CROPSTART = cropstart, CROPEND = cropend, CROPNAME = "vanggewas", CROPFIL = "vanggewas", CROPTYPE = 1) %>%
        arrange(CROPSTART)

      if (db_tmp$CROPNAME[nrow(db_tmp)] == "vanggewas") {
        db_tmp$CROPEND[nrow(db_tmp)] <- datelast
      }

    }

    # combine data
    if (s_crop_id == crop_id[1]) {
      db_crop <- db_tmp
    } else {
      db_crop <- rbind(db_crop, db_tmp)
    }

  }

  # upload sheet
  dbWriteTable(conn = conn, name = "Gewasrotatie", value = db_crop)
  index <- names(db_crop)[regexpr(pattern = "_id", text = names(db_crop)) > 0]
  statement <- str_c("CREATE INDEX swap_idx_Gewasrotatie ON Gewasrotatie (", str_c(index, collapse = ", "), ")")
  check <- dbExecute(conn = conn, statement = statement)

  message("- crop rotation... done")
}

#' Create table with bottom boundary
#'
#' @param ctrl character string. Name of controlfile.
#' @param conn connection of db-sqlite.
#' @importFrom stringr str_c str_replace str_which str_split
#' @importFrom fs path_package path_file dir_ls
#' @importFrom readr read_csv read_rds read_csv
#' @importFrom controlR get_dir
#' @importFrom RSQLite dbWriteTable dbExecute
#' @importFrom progress progress_bar
#' @keywords internal
create_table_wwl <- function(ctrl, conn) {

  # ---- initial part of procedure ----

  # load SWAP variables
  var_SWAP <- read_rds(file = str_c(path_package(package = "SWAPtools"), "/rds/swap_variables.rds"))

  # set directory datamodel
  dir_wwl <- get_dir(file = ctrl, item = "DIRWWL", create = FALSE, item_exists = FALSE)

  # set type of soil schematisation
  opt_bodem <- get_record(file = ctrl, item = "TYPE", opt = c("BOFEK2012", "BOFEK2020", "BODEM"))

  # ---- main part of procedure ----

  # collect all SWAP variables
  variable <- names(var_SWAP)
  for (rec in str_which(string = variable, pattern = "::")) {
    variable[rec] <- str_split(string = variable[rec], pattern = "::", simplify = TRUE)[, 2]
  }

  # list wwl sheets
  if (is.null(dir_wwl)) {
    path <- str_c(path_package(package = "WWLregionaal"), c("/csv", str_c("/csv/", opt_bodem)))
    file_csv <- dir_ls(path = path, type = "file", glob = "*.csv")
  } else {
    file_csv <- dir_ls(path = dir_wwl, type = "file", glob = "*.csv")
  }

  # upload wwl sheets
  pb <- progress_bar$new(total = length(file_csv), format = "- wwl settings... :percent", clear = TRUE)
  for (s_file in file_csv) {

    # load data sheet
    sh <- str_replace(string = path_file(s_file), pattern = ".csv", replacement = "")
    db <- suppressMessages(read_csv(file = s_file, lazy = FALSE))

    # delete empty columns
    column <- names(db)
    for (s_column in column) {

      # delete column if all records are empty
      if (all(is.na(db[ , s_column]))) {
        db <- db[ , names(db)[names(db) != s_column]]
      }

      # delete column in if not SWAP variable or index-column
      if (regexpr(pattern = "_id", text = s_column) < 0 & !s_column %in% variable) {
        db <- db[ , names(db)[names(db) != s_column]]
      }

      # convert datetime to date
      if (s_column %in% variable) {
        format <- var_SWAP[[match(x = s_column, table = variable)]]$format
        if (format == "date") {
          db[, s_column] <- as_date(deframe(db[, s_column]))
        }
      }
    }

    # upload sheet
    dbWriteTable(conn = conn, name = sh, value = db)
    index <- names(db)[regexpr(pattern = "_id", text = names(db)) > 0]
    statement <- str_c("CREATE INDEX swap_idx_", sh, " ON ", sh, " (", str_c(index, collapse = ", "), ")")
    check <- dbExecute(conn = conn, statement = statement)

    # set progress
    pb$tick()
  }

  message("- wwl settings... done")
}

#' Create table with bottom boundary
#'
#' @param ctrl character string. Name of controlfile.
#' @param conn connection of db-sqlite.
#' @param db_run tibble data frame. List of run_id and coordinates.
#' @importFrom stringr str_c str_replace str_replace_all str_split str_sub
#' @importFrom fs path_file path_dir path_ext
#' @importFrom controlR get_record is_numeric
#' @importFrom lubridate as_date year month day
#' @importFrom idfR get_data_idf
#' @importFrom ascR get_data_asc
#' @importFrom RSQLite dbWriteTable dbExecute
#' @importFrom tibble tibble
#' @importFrom dplyr %>% filter select rename mutate
#' @importFrom progress progress_bar
#' @keywords internal
create_table_bbc <- function(ctrl, conn, db_run) {

  # ---- initial part of procedure ----

  run_id <- x_crd <- y_crd <- msl <- scenario_id <- NULL
  gwl_nap <- gwl_mv <- rimlay <- NULL
  DATE1 <- DATE3 <- DATE5 <- GWLEVEL <- HAQUIF <- HBOT5 <- NULL

  depth <- 600

  # set period
  tstart <- get_record(file = ctrl, item = "TSTART")
  tend <- get_record(file = ctrl, item = "TEND")

  # set type of bottom boundary
  onderrand <- get_record(file = ctrl, item = "ONDERRAND", opt = c("GRONDWATERSTAND", "STIJGHOOGTE", "DRUKHOOGTE"))

  gwlevel <- get_record(file = ctrl, item = "GWLEVEL")
  if (onderrand == "STIJGHOOGTE") {
    weerstand <- get_record(file = ctrl, item = "WEERSTAND")
  }

  # indirect effects
  indirect <- TRUE
  text <- get_record(file = ctrl, item = "INDIRECT", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) indirect <- ifelse(text == "Yes", TRUE, FALSE)

  # ---- main part of procedure ----


  # --- direct ---

  # extract run_id and coordinates (direct)
  db <- db_run %>%
    filter(scenario_id == "direct") %>%
    select(run_id, msl, x_crd, y_crd)

  # check db
  if (nrow(db) > 0) {

    sh <- "Onderrand"

    # extract vertical resistance
    if (onderrand == "STIJGHOOGTE") {
      ext <- tolower(path_ext(path = weerstand))
      if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = weerstand), "'"))
      if (ext == "idf") db <- db %>% mutate(rimlay = get_data_idf(file = weerstand, x_crd = x_crd, y_crd = y_crd))
      if (ext == "asc") db <- db %>% mutate(rimlay = get_data_asc(file = weerstand, x_crd = x_crd, y_crd = y_crd))
    }

    # check extent head
    ext <- tolower(path_ext(path = gwlevel))
    if (!ext %in% c("asc", "idf")) stop(str_c("unable to load raster; unknown extent: '", path_file(path = gwlevel), "'"))

    # get all head in directory
    file <- path_file(path = gwlevel)
    pattern <- str_c(str_split(string = file, pattern = "\\{\\{YYYYMMDD\\}\\}", simplify = TRUE), collapse = "*|*")
    files <- path_file(dir_ls(path = path_dir(gwlevel), glob = pattern))
    if (length(files) == 0) stop("no heads found; check path 'GWLEVEL'")

    # extract all date
    pattern <- str_c(str_split(string = file, pattern = "\\{\\{YYYYMMDD\\}\\}", simplify = TRUE), collapse = "|")
    if (str_sub(string = pattern, start = 1, end = 1) == "|") pattern <- str_sub(string = pattern, start = 2, end = nchar(pattern))
    date <- str_replace_all(string = files, pattern = pattern, replacement = "")
    date <- date[is_numeric(text = date)]
    date <- as_date(date)
    date <- sort(date[date >= tstart-1 & date <= tend])
    if (length(date) == 0) stop("no heads found; check path 'GWLEVEL'")

    # create date-pattern
    YYYY <- year(date)
    MM <- formatC(x = month(date), format = "d", width = 2, flag = "0")
    DD <- formatC(x = day(date), format = "d", width = 2, flag = "0")
    YYYYMMDD <- str_c(YYYY, MM, DD)

    # extract groundwaterlevel
    rec <- 1:length(date)
    pb <- progress_bar$new(total = length(rec), format = "- bottom boundary... :percent", clear = TRUE)
    for (s_rec in rec) {
      file_gwl <- str_replace(string = gwlevel, pattern = "\\{\\{YYYYMMDD\\}\\}", replacement = YYYYMMDD[s_rec])
      if (ext == "idf") db <- db %>% mutate(gwl_nap = get_data_idf(file = file_gwl, x_crd = x_crd, y_crd = y_crd))
      if (ext == "asc") db <- db %>% mutate(gwl_nap = get_data_asc(file = file_gwl, x_crd = x_crd, y_crd = y_crd))

      db <- db %>%
        mutate(
          gwl_mv = pmin(100, pmax(100 * (gwl_nap - msl), -500))
        )
      if (onderrand == "GRONDWATERSTAND") {
        db_gwl <- db %>%
          rename(GWLEVEL = gwl_mv) %>%
          mutate(DATE1 = date[s_rec] + 1) %>%
          select(run_id, DATE1, GWLEVEL)
      }
      if (onderrand == "STIJGHOOGTE") {
        db_gwl <- db %>%
          rename(HAQUIF = gwl_mv) %>%
          mutate(DATE3 = date[s_rec] + 1) %>%
          select(run_id, DATE3, HAQUIF)
      }
      if (onderrand == "DRUKHOOGTE") {
        db_gwl <- db %>%
          mutate(
            DATE5 = date[s_rec] + 1,
            HBOT5 = gwl_mv + depth
          ) %>%
          select(run_id, DATE5, HBOT5)
      }

      # upload boundary condition (each date)
      append <- ifelse(s_rec == 1, FALSE, TRUE)
      dbWriteTable(conn = conn, name = sh, value = db_gwl, overwrite = !append, append = append)

      # upload initial condition (first date)
      if (s_rec == 1) {
        db_ini <- db %>% select(run_id, gwl_mv) %>% rename(GWLI = gwl_mv)
        if (onderrand == "STIJGHOOGTE") db_ini <- mutate(db_ini, RIMLAY = rimlay)
        dbWriteTable(conn = conn, name = "Initieel", value = db_ini)
        index <- names(db_ini)[regexpr(pattern = "_id", text = names(db_ini)) > 0]
        statement <- str_c("CREATE INDEX swap_idx_Initieel ON Initieel (", str_c(index, collapse = ", "), ")")
        check <- dbExecute(conn = conn, statement = statement)
      }

      # set progress
      pb$tick()

    }

    index <- names(db_gwl)[regexpr(pattern = "_id", text = names(db_gwl)) > 0]
    statement <- str_c("CREATE INDEX swap_idx_", sh, " ON ", sh, " (", str_c(index, collapse = ", "), ")")
    check <- dbExecute(conn = conn, statement = statement)

  }

  # --- indirect ---

  if (indirect) {

    db <- db_run %>%
      filter(scenario_id == "indirect") %>%
      select(run_id)

    # check db
    if (nrow(db) > 0) {

      sh <- "Onderrand_indirect"

      # extract run_id (indirect)
      run_id <- db %>% select(run_id) %>% deframe()
      rec <- length(run_id)

      # create bottom boundary with groundwaterlevel at 5m
      db_ind <- tibble(run_id = rep(x = run_id, times = 2), DATE5 = c(rep(x = tstart, times = rec), rep(x = tend, times = rec)), HBOT5 = depth - 500)

      # upload sheet
      dbWriteTable(conn = conn, name = sh, value = db_ind)
      index <- names(db_ind)[regexpr(pattern = "_id", text = names(db_ind)) > 0]
      statement <- str_c("CREATE INDEX swap_idx_", sh, " ON ", sh, " (", str_c(index, collapse = ", "), ")")
      check <- dbExecute(conn = conn, statement = statement)
    }
  }

  message("- bottom boundary... done")
}

#' Create plot.idf or plot.asc
#'
#' @param ctrl character string. Name of controlfile.
#' @param db_run tibble data frame. List of run_id and coordinates.
#' @importFrom stringr str_replace
#' @importFrom fs path_ext
#' @importFrom controlR get_record
#' @importFrom dplyr %>% mutate select filter
#' @importFrom RSQLite dbConnect dbGetQuery dbDisconnect
#' @importFrom idfR get_head_idf write_idf
#' @importFrom ascR get_head_asc write_asc
#' @keywords internal
#' @export create_plot_runid
create_plot_runid <- function(ctrl, db_run = NULL) {

  # ---- initial part of procedure ----

  run_id <- x_crd <- y_crd <- scenario_id <- value <- NULL

  # set name of sql-file
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # set extent modus
  zonal <- get_record(file = ctrl, item = "ZONAL", item_exists = FALSE)
  modus <- ifelse(is.null(zonal), "extent", "layer")

  # set extent
  if (modus == "layer") {
    zonal <- get_record(file = ctrl, item = "ZONAL")
  }
  if (modus == "extent") {
    cellsize <- get_record(file = ctrl, item = "CELLSIZE")
    xmin <- get_record(file = ctrl, item = "XMIN")
    xmax <- get_record(file = ctrl, item = "XMAX")
    ymin <- get_record(file = ctrl, item = "YMIN")
    ymax <- get_record(file = ctrl, item = "YMAX")
  }

  # set layer format
  format <- "idf"
  text <- get_record(file = ctrl, item = "FORMAT", opt = c("asc", "idf"), item_exists = FALSE)
  if (!is.null(text)) format <- text

  # ---- main part of procedure ----

  # set layer settings
  if (modus == "layer") {
    if (tolower(path_ext(zonal)) == "idf") {
      head <- get_head_idf(file = zonal)
      if (format == "asc") {
        if (head$ieq == 1) stop("Usage of non-equidistants not supported yet by asc format...")
        head$precision <- NULL
        head$minval <- NULL
        head$maxval <- NULL
        head$ieq <- NULL
      }
    }
    if (tolower(path_ext(zonal)) == "asc") {
      head <- get_head_asc(file = zonal)
      if (format == "idf") {
        head$precision <- "single"
        head$minval <- 0
        head$maxval <- 1
        head$ieq <- 0
      }
    }
  }
  if (modus == "extent") {
    head <- list()
    if (format == "idf") head$precision <- "single"
    head$ncol <- abs(xmax - xmin) / cellsize
    head$nrow <- abs(ymax - ymin) / cellsize
    head$xmin <- xmin
    head$xmax <- xmax
    head$ymin <- ymin
    head$ymax <- ymax
    if (format == "idf") head$minval <- 0
    if (format == "idf") head$maxval <- 1
    head$nodata <- -9999
    if (format == "idf") head$ieq <- 0
    head$dx <- cellsize
    head$dy <- cellsize
  }

  # open database
  if (is.null(db_run)) {
    conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql)
    db_run <- as_tibble(dbGetQuery(conn = conn, statement = str_c("SELECT run_id, x_crd, y_crd, scenario_id FROM Runs WHERE scenario_id in ('direct')")))
    dbDisconnect(conn = conn)
  }

  # set data (default nodata)
  db <- db_run %>%
    filter(scenario_id == "direct") %>%
    mutate(
      col = ifelse(x_crd == head$xmax, head$ncol, floor((x_crd - head$xmin) / head$dx) + 1),
      row = ifelse(y_crd == head$ymin, head$nrow, floor((head$ymax - y_crd) / head$dy) + 1),
      value = as.numeric(run_id)
    ) %>%
    select(col, row, value)

  # set data
  layer <- head
  layer$data <- db

  # write plot
  file <- str_replace(string = file_sql, pattern = path_ext(path = file_sql), replacement = format)
  if (format == "idf") write_idf(file = file, idf = layer)
  if (format == "asc") write_asc(file = file, asc = layer, datatype = "INT4S")

  message("- create runid-plot... done")
}


#' Create sqlite-database with SWAP-WOFOST settings
#'
#' @param ctrl character string. Name of controlfile.
#' @importFrom stringr str_c str_which str_replace
#' @importFrom fs path_package path_file file_delete file_exists dir_ls path_ext
#' @importFrom controlR get_record get_dir
#' @importFrom RSQLite dbConnect dbDisconnect dbWriteTable dbExecute
#' @importFrom dplyr %>% select mutate filter group_by summarise
#' @importFrom tibble tibble deframe
#' @export create_datamodel_WWL
create_datamodel_WWL <- function(ctrl) {

  # ---- initial part of procedure ----

  run_id <- scenario_id <- rain_id <- x_crd <- y_crd <- NULL

  message("create datamodel...")

  # check if rainfall is specified separately
  opt_meteo <- get_record(file = ctrl, item = "METEO", opt = c("STATION", "RADAR"), item_exists = FALSE)
  if (is.null(opt_meteo)) opt_meteo <- "STATION"

  # set name of sql-file
  file_sql <- get_record(file = ctrl, item = "FILSQL")

  # check split database
  split <- FALSE
  text <- get_record(file = ctrl, item = "SPLIT", opt = c("Yes", "No"), item_exists = FALSE)
  if (!is.null(text)) split <- ifelse(text == "Yes", TRUE, FALSE)
  n_split <- ifelse(split, get_record(file = ctrl, item = "NSPLIT"), 1)

  # ---- main part of procedure ----

  # set zonal
  db_run_all <- create_table_runs(ctrl = ctrl)

  # create database for rain
  if (opt_meteo == "RADAR") {
    db_rain <- db_run_all %>%
      filter(scenario_id == "direct") %>%
      group_by(rain_id) %>%
      summarise(
        x_crd = mean(x_crd),
        y_crd = mean(y_crd),
        .groups = "drop"
      ) %>%
      select(rain_id, x_crd, y_crd)
  }

  # set alternative file_sql
  file_tmp <- file_sql
  if (split) {
    file_ext <- path_ext(file_sql)
    file_tmp <- str_replace(string = file_sql, pattern = str_c(".", file_ext), replacement = str_c("_\\{\\{SPLIT\\}\\}.", file_ext))
  }

  # set split in database
  n_rec <- nrow(db_run_all)
  n_run <- ceiling(n_rec / n_split)
  db_run_all <- db_run_all %>%
    mutate(split = ceiling(run_id / n_run))

  # loop over number of databases to create
  for (i_split in 1:n_split) {

    # split runs
    db_run <- db_run_all %>%
      filter(split == i_split) %>%
      select(-split)

    # set filename database
    file_out <- str_replace(string = file_tmp, pattern = "\\{\\{SPLIT\\}\\}", formatC(x = i_split, format = "d", width = 2, flag = "0"))
    message(str_c("\ncreate database: ", path_file(file_out)))

    # open database
    if (file_exists(path = file_out)) file_delete(path = file_out)
    conn <- dbConnect(RSQLite::SQLite(), dbname = file_out)

    # upload runs
    dbWriteTable(conn = conn, name = "Runs", value = db_run)
    index <- names(db_run)[regexpr(pattern = "_id", text = names(db_run)) > 0]
    statement <- str_c("CREATE INDEX swap_idx_Runs ON Runs (", str_c(index, collapse = ", "), ")")
    check <- dbExecute(conn = conn, statement = statement)

    # --- meteorology ---

    # add meteorology
    create_table_meteo(ctrl = ctrl, conn = conn, db_run = db_run)

    # add rainfall
    if (opt_meteo == "RADAR") create_table_rain(ctrl = ctrl, conn = conn, db_run = db_run, db_rain = db_rain)

    # --- crop rotation ---

    # set sheet crop rotation
    create_table_croprotation(ctrl = ctrl, conn = conn, db_run = db_run)

    # --- watervision agriculture ---

    # add wwl tables
    create_table_wwl(ctrl = ctrl, conn = conn)

    # --- bottom boundary ---

    # add bottom boundary
    create_table_bbc(ctrl = ctrl, conn = conn, db_run = db_run)

    # close connection
    dbDisconnect(conn = conn)
  }

  # --- create plot ---

  create_plot_runid(ctrl = ctrl, db_run = db_run_all)

  # create database of all runs (in case of split)
  if (split) {

    # open database
    if (file_exists(path = file_sql)) file_delete(path = file_sql)
    conn <- dbConnect(RSQLite::SQLite(), dbname = file_sql)

    # upload runs
    dbWriteTable(conn = conn, name = "Runs", value = db_run_all)
    index <- names(db_run_all)[regexpr(pattern = "_id", text = names(db_run_all)) > 0]
    statement <- str_c("CREATE INDEX swap_idx_Runs ON Runs (", str_c(index, collapse = ", "), ")")
    check <- dbExecute(conn = conn, statement = statement)

    # close connection
    dbDisconnect(conn = conn)

  }

}
