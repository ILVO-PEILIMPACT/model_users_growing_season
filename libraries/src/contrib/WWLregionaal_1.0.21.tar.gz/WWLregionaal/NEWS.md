# WWLregionaal 1.0.21 (2022-10-14)

* multicore analyse

# WWLregionaal 1.0.20 (2022-09-28)

* always add rain_id to Runs

# WWLregionaal 1.0.19 (2022-06-23)

* multicore op basis van opsplitsing datamodel
* check op succesvolle simulaties
* opschonen controlfiles multicore

# WWLregionaal 1.0.18 (2022-05-09)

* hide internal functions in Help Pages
* update R-pakketten

# WWLregionaal 1.0.17 (2022-04-13)

* opties voor keyword METEO aangepast
* opties voor keyword ONDERRAND aangepast

# WWLregionaal 1.0.16 (2022-01-04)

* garbage collection (output)

# WWLregionaal 1.0.15 (2022-01-04)

* bug bij laden neerslag indirecte runs opgelost

# WWLregionaal 1.0.14 (2021-12-28)

* specificatie gewas en bodem met code (optioneel)
* neerslag data verwerken op basis van resolutie
* bug bij laden onderrand opgelost combinatie van opsplitsen database en indirecte runs
* update R-pakketten

# WWLregionaal 1.0.13 (2021-10-22)

* andere opzet voor neerslag afkomstig van radarbeelden (optioneel)

# WWLregionaal 1.0.12 (2021-08-26)

* opsplitsen van database (optioneel)

# WWLregionaal 1.0.11 (2021-08-23)

* niet uitvoeren van indirecte effecten (optioneel)

# WWLregionaal 1.0.10 (2021-08-16)

* update van WWL version 3.0.0
* meteorologische condities in vorm van radarbeelden
* selectie uitvoer (optioneel)
* update R-pakketten

# WWLregionaal 1.0.9 (2021-03-19)

* update van WWLanalyse

# WWLregionaal 1.0.8 (2021-02-10)

* bug verwijderd in geval van irrigatie (CIRRS)

# WWLregionaal 1.0.7 (2020-12-04)

* bug verwijderd bij create_plot_runid

# WWLregionaal 1.0.6 (2020-11-27)

* wegschrijven van asc-uitvoer
* aardappel_overig gesplitst

# WWLregionaal 1.0.5 (2020-11-06)

* vertaling naar euro's (referentiegewas)

# WWLregionaal 1.0.4 (2020-10-22)

* aanmaken plot.idf waarbij optioneel de sqlite-database wordt geraadpleegd

# WWLregionaal 1.0.3 (2020-10-06)

* update R-paketten

# WWLregionaal 1.0.2 (2020-07-23)

* verwijzing naar WWL-maatwerk verwijderd

# WWLregionaal 1.0.1 (2020-07-03)

* wegschrijven van gewasopbrengsten (biomassa en euro's)

# WWLregionaal 1.0.0 (2020-06-12)

* WWLregionaal beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html

# WWLregionaal 0.1.10 (2020-06-02)

* inlezen van asc-files

# WWLregionaal 0.1.9 (2020-05-25)

* controle op begin en einddatum van de simulatie
* alleen GHG en GLG wegschrijven als periode langer is dan 4 jaar
* wegschrijven van langjarig gemiddelde derving bij wintergewassen

# WWLregionaal 0.1.8 (2020-04-28)

* selectie op basis van zonal

# WWLregionaal 0.1.7 (2020-04-22)

* aanmaken plot.idf

# WWLregionaal 0.1.6 (2020-04-17)

* correctie onderrandvoorwaarde

# WWLregionaal 0.1.5 (2020-04-14)

* consistente benaming van kolommen
* wegschrijven van directe effecten015

# WWLregionaal 0.1.4 (2020-03-30)

* foutmelding bij wintergewassen opgelost

# WWLregionaal 0.1.3 (2020-03-11)

* waarschuwing indien vertaaltabel voor gewas en bodem niet volledig is
* resultaten ook voor het eerste jaar

# WWLregionaal 0.1.2 (2020-03-11)

* bodemprofielen van BOFEK (keuze uit 72 of 370 profielen)
* grondwaterstand afkappen op 5 m-mv
* wegschrijven van geaggregeerde resultaten

# WWLregionaal 0.1.1 (2020-03-10)

* solute_id toegevoegd bij indirecte runs

# WWLregionaal 0.1.0 (2020-03-02)

* eerste versie van de WWLregionaal
