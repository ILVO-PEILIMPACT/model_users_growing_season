#' Load setup asc
#'
#' @param file character string, filename.
#' @importFrom fs file_exists path_file
#' @importFrom stringr str_c
#' @importFrom raster raster ncol nrow NAvalue
#' @export get_head_asc
#' @examples
#' # extract setup of asc-file
#' file <- system.file("extdata/test.asc", package = "ascR")
#' get_head_asc(file = file)
get_head_asc <- function(file) {

  # ---- initial part of procedure ----

  # check if file exists
  if (!file_exists(file)) stop(str_c("file '", path_file(file), "' does not exists"))

  # create empty list
  head_asc <- list()

  # ---- main part of procedure ----

  # load geometry
  layer <- raster(x = file)

  # load number of columns and rows
  head_asc$ncol <- ncol(layer)
  head_asc$nrow <- nrow(layer)

  # load extent
  head_asc$xmin <- layer@extent@xmin
  head_asc$xmax <- layer@extent@xmax
  head_asc$ymin <- layer@extent@ymin
  head_asc$ymax <- layer@extent@ymax

  # load nodata-value
  nodata <- NAvalue(x = layer)
  if (nodata == -Inf | nodata == Inf | is.na(nodata)) nodata <- -9999
  head_asc$nodata <- nodata

  # set cellsize
  head_asc$dx <- (head_asc$xmax - head_asc$xmin) / head_asc$ncol
  head_asc$dy <- (head_asc$ymax - head_asc$ymin) / head_asc$nrow

  # ---- return of procedure ----

  return(head_asc)
}

#' Load data asc
#'
#' @param file character string, filename
#' @param col numeric vector, column to extract
#' @param row numeric vector, row to extract
#' @param x_crd numeric vector, x-coordinate to extract
#' @param y_crd numeric vector, y-coordinate to extract
#' @importFrom fs file_exists path_file
#' @importFrom stringr str_c
#' @importFrom raster raster xFromCol yFromRow extract extent
#' @details by default all data is extracted, vector starts from upper left corner
#' @export get_data_asc
#' @examples
#' # extract data of asc-file
#' file <- system.file("extdata/test.asc", package = "ascR")
#' get_data_asc(file = file)
#' get_data_asc(file = file, col = c(1,3), row = c(1,1))
#' get_data_asc(file = file, x_crd = c(219001,219050), y_crd = c(501100, 501099))
get_data_asc <- function(file, col = NULL, row = NULL, x_crd = NULL, y_crd = NULL) {

  # ---- initial part of procedure ----

  if (!file_exists(file)) stop(str_c("file '", path_file(file), "' does not exists"))

  # load geometry
  layer <- raster(x = file)

  # ---- main part of procedure ----

  # set extraction modus
  modus <- "all"
  if ((!is.null(col) & !is.null(row)) | (!is.null(x_crd) & !is.null(y_crd))) modus <- "vector"

  # get asc setup
  head_asc <- get_head_asc(file = file)

  # set coodinates
  if (!is.null(col) & !is.null(row)) {
    x_crd <- xFromCol(object = layer, col = col)
    y_crd <- yFromRow(object = layer, row = row)
  }

  # check if selected point is in domain
  if (modus == "vector") {
    if (length(x_crd) != length(y_crd)) stop("size of vector 'col' and 'row' should be equal")
    if (!all(x_crd >= head_asc$xmin) | !all(x_crd <= head_asc$xmax)) stop("point(s) selected outside domain")
    if (!all(y_crd >= head_asc$ymin) | !all(y_crd <= head_asc$ymax)) stop("point(s) selected outside domain")
  }

  # load data
  if (modus == "all") {
    data <- extract(x = layer, y = extent(head_asc$xmin, head_asc$xmax, head_asc$ymin, head_asc$ymax))
  }
  if (modus == "vector") {
    data <- extract(x = layer, y = cbind(x_crd, y_crd))
  }

  # replace NA by nodata
  data[is.na(data)] <- head_asc$nodata

  # ---- return of procedure ----

  return(data)

}

#' Read asc
#'
#' @param file character string, filename
#' @param col numeric vector, column to extract
#' @param row numeric vector, row to extract
#' @param x_crd numeric vector, x-coordinate to extract
#' @param y_crd numeric vector, y-coordinate to extract
#' @importFrom fs file_exists path_file
#' @importFrom stringr str_c
#' @importFrom raster raster xFromCol yFromRow colFromX rowFromY
#' @importFrom tibble tibble
#' @details by default all data is extracted, vector starts from upper left corner
#' @export read_asc
#' @examples
#' # read asc-file
#' file <- system.file("extdata/test.asc", package = "ascR")
#' read_asc(file = file)
read_asc <- function(file, col = NULL, row = NULL, x_crd = NULL, y_crd = NULL) {

  # ---- initial part of procedure ----

  if (!file_exists(file)) stop(str_c("file '", path_file(file), "' does not exists"))

  # load geometry
  layer <- raster(x = file)

  # ---- main part of procedure ----

  # get idf setup
  asc <- get_head_asc(file = file)

  # set coodinates
  if (!is.null(col) & !is.null(row)) {
    x_crd <- xFromCol(object = layer, col = col)
    y_crd <- yFromRow(object = layer, row = row)
  }

  # get data asc
  value <- get_data_asc(file = file, x_crd = x_crd, y_crd = y_crd)

  # set columns and rows (if needed)
  if (is.null(col) & is.null(row)) {
    if (is.null(x_crd) & is.null(y_crd)) {
      col <- rep(x = 1:asc$ncol, times = asc$nrow)
      row <- sort(rep(x = 1:asc$nrow, times = asc$ncol))
    } else {
      col <- colFromX(object = layer, x = x_crd)
      row <- rowFromY(object = layer, y = y_crd)
    }
  }

  # set asc data
  asc$data <- tibble(col = col, row = row, value = value)


  # ---- return of procedure ----

  return(asc)
}

#' Write asc
#'
#' @param file character string, filename.
#' @param asc list, setup and data of asc-layer.
#' @param datatype output data type, default 'FLT4S'.
#' @importFrom fs file_exists file_delete path_file
#' @importFrom stringr str_c
#' @importFrom raster raster writeRaster
#' @export write_asc
write_asc <- function(file, asc, datatype = "FLT4S") {

  # ---- initial part of procedure ----

  # check if file exists
  if (file_exists(file)) file_delete(path = file)

  # ---- main part of procedure ----

  # set data
  nrec <- asc$ncol * asc$nrow
  data <- asc$data
  if (nrow(data) != nrec) {
    value <- rep(x = asc$nodata, times = nrec)
    value[(asc$ncol * (data$row - 1)) + data$col] <- data$value
  } else {
    value <- data$value[order(data$row, data$col)]
  }

  # create raster
  layer <- raster(nrows = asc$nrow, ncols = asc$ncol, xmn = asc$xmin, xmx = asc$xmax, ymn = asc$ymin, ymx = asc$ymax, vals = value)

  # write raster
  check <- writeRaster(x = layer, filename = file, format = "ascii", datatype = datatype, overwrite = FALSE, NAflag = asc$nodata)

}

#' Get column number
#'
#' @param file character string, filename
#' @param x_crd numeric vector, x-coordinate
#' @importFrom fs file_exists path_file
#' @importFrom stringr str_c
#' @importFrom raster raster colFromX
#' @export get_col_asc
#' @examples
#' # get column number from asc-file based on x-coordinate(s)
#' file <- system.file("extdata/test.asc", package = "ascR")
#' get_col_asc(file = file, x_crd = c(219001,219050))
get_col_asc <- function(file, x_crd) {

  # ---- initial part of procedure ----

  if (!file_exists(file)) stop(str_c("file '", path_file(file), "' does not exists"))

  # load geometry
  object <- raster(x = file)

  # ---- main part of procedure ----

  # set column
  col <- colFromX(object = object, x = x_crd)

  # ---- return of procedure ----

  return(col)

}

#' Get row number
#'
#' @param file character string, filename
#' @param y_crd numeric vector, y-coordinate
#' @importFrom fs file_exists path_file
#' @importFrom stringr str_c
#' @importFrom raster raster rowFromY
#' @export get_row_asc
#' @examples
#' # get row number from asc-file based on y-coordinate(s)
#' file <- system.file("extdata/test.asc", package = "ascR")
#' get_row_asc(file = file, y_crd = c(501100, 501099))
get_row_asc <- function(file, y_crd) {

  # ---- initial part of procedure ----

  if (!file_exists(file)) stop(str_c("file '", path_file(file), "' does not exists"))

  # load geometry
  object <- raster(x = file)

  # ---- main part of procedure ----

  # set column
  row <- rowFromY(object = object, y = y_crd)

  # ---- return of procedure ----

  return(row)

}

#' Add coordinates to data of asc-layer
#'
#' @param asc list, setup and data of asc-layer.
#' @importFrom dplyr %>% mutate
#' @export xy_crd_asc
#' @examples
#' # add coordinates to asc-layer
#' file <- system.file("extdata/test.asc", package = "ascR")
#' asc <- read_asc(file = file)
#' xy_crd_asc(asc = asc)
xy_crd_asc <- function(asc) {

  # ---- main part of procedure ----

  # clip body
  asc$data <- asc$data %>%
    mutate(
      x_crd = asc$xmin + (0.5 * asc$dx) + (col - 1) * asc$dx,
      y_crd = asc$ymax - (0.5 * asc$dy) - (row - 1) * asc$dy,
    )

  # ---- return of procedure ----

  return(asc)
}

#' Clip asc-layer based on extent
#'
#' @param asc list, setup and data of asc-layer.
#' @param extent list, new extent of layer
#' @importFrom dplyr %>% mutate filter select
#' @export clip_asc
#' @examples
#' # create extent
#' extent <- list(xmin = 219000, xmax = 219050, ymin = 501000, ymax = 501050)
#'
#' # clip asc-layer based on extent
#' file <- system.file("extdata/test.asc", package = "ascR")
#' asc <- read_asc(file = file)
#' clip_asc(asc = asc, extent = extent)
clip_asc <- function(asc, extent) {

  x_crd <- y_crd <- value <- NULL

  # ---- main part of procedure ----

  # clip body
  db <- asc$data %>%
    mutate(
      x_crd = asc$xmin + (0.5 * asc$dx) + (col - 1) * asc$dx,
      y_crd = asc$ymax - (0.5 * asc$dy) - (row - 1) * asc$dy,
      col = col - (extent$xmin - asc$xmin) / asc$dx,
      row = row - (asc$ymax - extent$ymax) / asc$dy
    ) %>%
    filter(x_crd > extent$xmin & x_crd < extent$xmax & y_crd > extent$ymin & y_crd < extent$ymax) %>%
    select(col, row, value)

  # update layer information
  asc$ncol <- max(db$col)
  asc$nrow <- max(db$row)
  asc$xmin <- extent$xmin
  asc$xmax <- extent$xmax
  asc$ymin <- extent$ymin
  asc$ymax <- extent$ymax
  asc$data <- db

  # ---- return of procedure ----

  return(asc)
}
