#' ascR
#'
#' A tool for handling asc-files
#'
#' Try the examples to get convenient with \pkg{ascR}.
#'
"_PACKAGE"
