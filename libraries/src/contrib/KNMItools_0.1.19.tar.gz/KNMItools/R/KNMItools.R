#' KNMItools
#'
#' R-scripts for downloading meterological and precipitation data for all \href{https://www.knmi.nl/home}{KNMI} stations.
#'
"_PACKAGE"
