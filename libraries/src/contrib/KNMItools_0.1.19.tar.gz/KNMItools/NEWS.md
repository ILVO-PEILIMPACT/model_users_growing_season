# KNMItools 0.1.19 (2022-10-20)

* all_of niet toepassen in geval van rlang berekening (download_meteo_KNMI)

# KNMItools 0.1.18 (2022-10-03)

* update analyse_precipitation_KNMI

# KNMItools 0.1.17 (2022-04-25)

* update controlR

# KNMItools 0.1.16 (2022-04-25)

* vernieuwde versie van create_label_graph

# KNMItools 0.1.15 (2022-04-12)

* code neerslagstation nu met 3 cijfers weergegeven in url

# KNMItools 0.1.14 (2022-03-11)

* meteogegevens AgERA5 en neerslaggegevens CHIRPS (alleen indien toegang tot WUR netwerk)

# KNMItools 0.1.13 (2021-11-16)

* verandering van header meteo-files

# KNMItools 0.1.12 (2021-10-21)

* vergelijking neerslag met meerdere weerstations tegelijk

# KNMItools 0.1.11 (2021-08-16)

* check besturingssysteem bij gebruik van read_csv (readr)
* download_KNMI is vervangen door download_data (controlR)

# KNMItools 0.1.10 (2021-08-12)

* voor voor tijdelijke folder file_temp (fs)

# KNMItools 0.1.9 (2021-07-08)

* check ontbrekende meteogegevens in vervangend station

# KNMItools 0.1.8 (2021-05-18)

* controle station keuze

# KNMItools 0.1.7 (2021-04-14)

* vergelijking neerslag (double-mass curve)

# KNMItools 0.1.6 (2021-03-10)

* download van KNMI data werkt tijdelijk niet in verband met overstap op nieuw systeem
* nu verholpen door de oude zip-bestanden te downloaden

# KNMItools 0.1.5 (2021-02-15)

* berekening actuele vochtspanning optioneel op basis van gemiddelde luchvochtigheid
* duplicatie bij opvulling met hetzelfde station

# KNMItools 0.1.4 (2020-10-22)

* toevoegen van deframe na update tibble

# KNMItools 0.1.3 (2020-10-06)

* update R-paketten

# KNMItools 0.1.2 (2020-03-13)

* analyse beschikbaarheid van meetgegevens
* ontbrekende meteogegevens opvullen met ander station

# KNMItools 0.1.1 (2020-03-12)

* berekening van de referentieverdamping (FAO 56: vergelijking 6)

# KNMItools 0.1.0 (2020-02-27)

* eerste versie van de KNMItools
