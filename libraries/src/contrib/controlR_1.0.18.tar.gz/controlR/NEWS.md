# controlR 1.0.18 (2022-07-26)

* progress set to FALSE

# controlR 1.0.17 (2022-05-18)

* minor adjustment in create_label ('in' was not allowed in label)

# controlR 1.0.16 (2022-05-09)

* minor adjustment in create_label

# controlR 1.0.15 (2022-04-25)

* revision of create_label_graph

# controlR 1.0.14 (2021-11-03)

* eenheden toegevoegd (LINGRA)

# controlR 1.0.13 (2021-08-16)

* check windows besturingssysteem
* naamgeving functies meer in lijn met R dialect
* download functie toegevoegd
* get_digits functie toegevoegd

# controlR 1.0.12 (2021-02-15)

* opschonen argumenten

# controlR 1.0.11 (2020-10-22)

* file_exists niet meer afhankelijk van fs
* eenheden toegevoegd
* update R-paketten

# controlR 1.0.10 (2020-04-25)

* schrijf string als integer weg indien mogelijk

# controlR 1.0.9 (2020-04-15)

* sta tekst toe in str_seq en seq_str
* verzameling van variabelen (get_variable)

# controlR 1.0.8 (2020-03-30)

* basename vervangen door path_file
* negeer spaties binnen aanhalingstekens (get_table)

# controlR 1.0.7 (2020-03-13)

* ggplot functionaliteiten

# controlR 1.0.6 (2020-03-06)

* waarschuwing controle date-check verholpen
* berekening van dagnummer (dayyear) en hydrologisch jaar (hydryear)

# controlR 1.0.5 (2020-02-28)

* optioneel of directory is gespecificeerd in controlfile

# controlR 1.0.4 (2019-12-20)

* verbetering inlezen van numeriek reeks

# controlR 1.0.3 (2019-12-09)

* date-check mag vier vormen aannemen: %Y-%m-%d, %d-%m-%Y, %Y-%b-%d of %d-%b-%Y 

# controlR 1.0.2 (2019-12-02)

* inlezen van numerieke reeks

# controlR 1.0.1 (2019-11-08)

* tabs worden bij het inlezen van de controlfile vervangen
* een keyword mag zowel met als zonder quotes worden gespecificeerd

# controlR 1.0.0 (2019-10-20)

* eerste versie van de controlR beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
