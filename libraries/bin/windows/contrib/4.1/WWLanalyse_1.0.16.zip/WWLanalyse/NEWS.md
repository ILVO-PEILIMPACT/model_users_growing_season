# WWLanalyse 1.0.16 (2022-06-01)

* bug indirecte effecten appelbomen

# WWLanalyse 1.0.15 (2022-06-01)

* bug in case of crop rotation solved
* ggsave instead of png

# WWLanalyse 1.0.14 (2022-05-20)

* bug in case of zero growth solved

# WWLanalyse 1.0.13 (2022-05-09)

* update controlR and SWAPtools

# WWLanalyse 1.0.12 (2022-04-22)

* hide internal functions in Help Pages
* revision of get_gxg and create_label_graph

# WWLanalyse 1.0.11 (2021-12-27)

* update R-pakketten

# WWLanalyse 1.0.10 (2021-08-16)

* update R-pakketten

# WWLanalyse 1.0.9 (2021-07-20)

* duplicaat aardappel_overig verwijdert

# WWLanalyse 1.0.8 (2021-05-25)

* toevoegen van WWL variabelen (SWIND)

# WWLanalyse 1.0.7 (2021-03-19)

* nieuwe analyse data plot

# WWLanalyse 1.0.6 (2021-03-10)

* geen grondwaterkarakteristieken plotten bij korte simulatieperiode 

# WWLanalyse 1.0.5 (2020-02-09)

* legenda apart plotten

# WWLanalyse 1.0.4 (2020-10-28)

* onderdrukken van meldingen naar het scherm bij opvragen plotgegevens

# WWLanalyse 1.0.3 (2020-10-06)

* update R-paketten

# WWLanalyse 1.0.2 (2020-08-26)

* aanmaken van gewas-kaartlaag vanuit sql-database

# WWLanalyse 1.0.1 (2020-07-08)

* plotten van figuren aan de hand van templates

# WWLanalyse 1.0.0 (2020-06-12)

* eerste versie van de WWLanalyse
