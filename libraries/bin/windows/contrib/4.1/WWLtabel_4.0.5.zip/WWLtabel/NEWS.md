# WWLtabel 4.0.5 (2022-05-09)

* hide internal functions in Help Pages
* update R-paketten

# WWLtabel 4.0.4 (2021-11-01)

* uitvoer zetmeelaardappelen

# WWLtabel 4.0.3 (2021-08-16)

* selectie uitvoer variabelen
* update R-pakketten

# WWLtabel 4.0.2 (2021-04-13)

* metarelaties 3.0.0
* check input

# WWLtabel 4.0.1 (2020-10-22)

* update R-paketten

# WWLtabel 4.0.0 (2020-06-12)

* metarelaties 2.0.0
* optie onderwaterdrainage niet meer opvraagbaar
* idf-bestanden inlezen en wegschrijven

# WWLtabel 3.0.3 (2020-02-11)

* mogelijkheid tot lokaal testen van database

# WWLtabel 3.0.2 (2019-11-08)

* controle op omgekeerde peilen (ghg < glg)
* versnelling bij inlezen van rasterbestanden
* opgeven password bij gebruik proxy

# WWLtabel 3.0.1 (2019-11-01)

* waarschuwing bij beregening verbeterd
* opgeven van een proxyserver (optioneel)

# WWLtabel 3.0.0 (2019-10-20)

* WWLtabel beschikbaar als R-pakket: https://waterwijzerlandbouw.wur.nl
* verbetering bilineaire interpolatie in geval van zeer weinig dynamiek in de grondwaterstanden
* beregening bij groenteteelt beschikbaar

# WWLtabel 2.0.2 (2019-04-05)

* versiebeheer database ingevoerd
* oplossing voor foutmelding 'recursive indexing failed at level 2'

# WWLtabel 2.0.1 (2019-03-05)

* fout in rastermodule opgelost 'object 'Raster' not found'

# WWLtabel 2.0.0 (2019-02-20)

* toevoeging van onderwaterdrainage
* gegevens opgeslagen in hogere resolutie

# WWLtabel 1.1.1 (2019-01-18)

* verbeterde afhandeling van fouten
* draait nu ook op LINUX
* te benaderen vanuit R ten behoeve van gevoeligheidsanalyses

# WWLtabel 1.1.0 (2018-12-11)

* inbouw van bilineaire interpolatie, gewasschades worden nu geïnterpoleerd voor fijnmaziger resultaten

# WWLtabel 1.0.2 (2018-11-09)

* beregening voor bloembollen (tulp en lelie) zijn beschikbaar

# WWLtabel 1.0.1 (2018-10-22)

* forse verhoging van de rekensnelheid


# WWLtabel 1.0.0 (2018-10-15)

* eerste versie van de WWLtabel beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
