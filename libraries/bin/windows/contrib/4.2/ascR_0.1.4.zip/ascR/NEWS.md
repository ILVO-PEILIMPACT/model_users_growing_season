# ascR 0.1.4 (2022-04-13)

* opvragen van xy-coordinaten
* clip functie op basis van extent

# ascR 0.1.3 (2021-12-27)

* opvragen van kolom en rij nummers op basis van coordinaten

# ascR 0.1.2 (2020-10-06)

* update R-paketten

# ascR 0.1.1 (2020-07-14)

* expliciet wegschrijven van nodata waarde (write_asc)

# ascR 0.1.0 (2020-06-03)

* eerste versie van de ascR beschikbaar op https://waterwijzerlandbouw.wur.nl/index.html
